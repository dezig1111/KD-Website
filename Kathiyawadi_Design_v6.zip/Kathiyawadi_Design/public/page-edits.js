/* Applies the text, button and link changes made with "Edit this page" in the admin.
   Saved in the database as content "pageEdits": { "/page": [ {sel, html?, href?, hide?} ], "*": [...] }
   "*" holds changes to the header and footer, which appear on every page. */
(function () {
  var all = (window.__KD__ && window.__KD__.pageEdits) || {};
  var path = location.pathname.replace(/\/$/, '') || '/';
  var ALLOWED = {BR: 1, EM: 1, STRONG: 1, B: 1, I: 1, SPAN: 1};

  // Only simple formatting is kept (line breaks, bold, italic); everything else becomes plain text.
  function clean(html) {
    var t = document.createElement('template');
    t.innerHTML = String(html);
    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (n) {
        if (n.nodeType === 1) {
          if (!ALLOWED[n.tagName]) { n.replaceWith(document.createTextNode(n.textContent)); return; }
          while (n.attributes.length) n.removeAttribute(n.attributes[0].name);
          walk(n);
        } else if (n.nodeType !== 3) n.remove();
      });
    })(t.content);
    return t.innerHTML;
  }
  function safeHref(h) { return /^(\/|#|https?:\/\/|mailto:|tel:)/i.test(String(h || '').trim()) ? String(h).trim() : null; }
  function find(sel) { try { return document.querySelector(sel); } catch (e) { return null; } }

  function applyOne(e) {
    var el = find(e.sel);
    if (!el) return;
    if (e.hide) { el.style.setProperty('display', 'none', 'important'); return; }
    el.style.removeProperty('display');
    if (typeof e.html === 'string') {
      var h = clean(e.html);
      if (el.innerHTML !== h) el.innerHTML = h;
      if (el.dataset && el.dataset.en !== undefined) el.dataset.en = h;
    }
    if (e.href !== undefined) {
      var a = el.closest('a');
      var href = safeHref(e.href);
      if (a && href) a.setAttribute('href', href);
    }
  }
  function apply() { [].concat(all['*'] || [], all[path] || []).forEach(applyOne); }

  window.KDPageEdits = {all: all, path: path, clean: clean, safeHref: safeHref, apply: apply, applyOne: applyOne};
  if ((all['*'] || []).length || (all[path] || []).length) {
    apply();
    // Some parts of the page are drawn a moment later by the animation scripts.
    setTimeout(apply, 700);
    setTimeout(apply, 2500);
  }
})();
