// Swaps photos/reels the admin replaced (see Admin → Photos & Reels).
// Loaded in <head> before the page body so it catches every image and video.
(function(){var m=(window.__KD__&&window.__KD__.media)||{};if(!Object.keys(m).length)return;
function sw(u){if(!u||u.indexOf('/')<0)return u;try{var p=new URL(u,location.href);return p.origin===location.origin&&m[p.pathname]?m[p.pathname]:u}catch(e){return u}}
function one(el){['src','poster'].forEach(function(a){var v=el.getAttribute(a);if(!v)return;var n=sw(v);if(n!==v){el.setAttribute(a,n);if(el.tagName==='SOURCE'&&el.parentNode&&el.parentNode.load)el.parentNode.load()}})}
function fix(el){if(el.nodeType!==1)return;if(/^(IMG|VIDEO|SOURCE)$/.test(el.tagName))one(el);if(el.querySelectorAll)el.querySelectorAll('img,video,source').forEach(one)}
new MutationObserver(function(rs){rs.forEach(function(r){if(r.type==='attributes')fix(r.target);else r.addedNodes.forEach(fix)})}).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src','poster']});})();
