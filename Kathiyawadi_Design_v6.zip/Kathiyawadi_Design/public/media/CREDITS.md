# Media credits
- cafe-campaign.webp: original AI-generated product photography for this demo, generated with the built-in image tool. Prompt: portrait 4:5 premium ceramic espresso cup, saucer, coffee beans and orange marigold on a warm burnt-orange studio surface; editorial side sunlight, no text, negative space above. Optimized to 1080 × 1350.
- coffee-reel.mp4: original 720 × 1280 (9:16) motion study made from the generated cafe asset, with a gentle camera move and campaign typography. Silent by design.
- architecture.jpg: Unsplash photo, https://images.unsplash.com/photo-1600585154340-be6161a56a0c, used as sample concept photography. Not commissioned agency photography.
- coffee-editorial.jpg: Unsplash sample, https://images.unsplash.com/photo-1495474472287-4d71bcdd2085.
- bloom-reel.mp4 and flower-poster.jpg: MDN CC0 flower demonstration footage, https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4, reframed to 720 × 1280 (9:16). Silent.
All campaigns and UI mockups are illustrative concepts. Replace these with approved client assets when available.
- space-reel.mp4: original 720 × 1280 (9:16) camera-move concept from the credited architecture photograph. Silent by design.
- studio-workspace-sample.jpg: illustrative workspace photograph from https://images.unsplash.com/photo-1497366811353-6870744d04b2. It is explicitly labelled as a sample and must be replaced with the company's actual photograph. Leadership portraits are labelled SVG placeholders, not photos of the named people.
- leadership-founder-sample.jpg, leadership-coo-sample.jpg, leadership-social-sample.jpg: sample Unsplash portraits requested for layout only, not actual employees. Source image IDs: photo-1500648767791-00dcc994a43e, photo-1472099645785-5658abf4ff4e, photo-1534528741775-53994a69daeb. The page explicitly labels these as sample portraits.

- matter-reel.mp4 and color-reel.mp4: original silent 720 × 1280 typography/composition motion studies created with FFmpeg for this website. Poster JPGs are frames from the corresponding reels. Uses DejaVu Sans, an open font installed in the rendering environment.
