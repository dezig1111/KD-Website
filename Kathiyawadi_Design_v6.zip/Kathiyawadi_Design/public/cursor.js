/* KD cursor: the round KD logo is the mouse pointer on the page. Over images
   and buttons (and links, cards, form fields) the logo hides and the normal
   pointer is shown instead. Mouse/trackpad only; off for touch screens and for
   visitors who prefer reduced motion. */
(() => {
  if (!matchMedia('(pointer: fine)').matches || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const root = document.documentElement;
  const dot = document.createElement('div');
  dot.className = 'kd-cursor';
  dot.setAttribute('aria-hidden', 'true');
  dot.innerHTML = '<img src="/media/kd-mark.png" alt="">';
  document.body.append(dot);
  // Only hide the normal pointer once the KD logo has loaded, so there is always a visible pointer.
  const img = dot.querySelector('img');
  const ready = () => root.classList.add('kd-cursor-on');
  if (img.complete && img.naturalWidth) ready(); else { img.addEventListener('load', ready); img.addEventListener('error', () => dot.remove()); }

  // Where the normal pointer takes over (the KD logo is hidden there).
  const NATIVE = 'a, button, label, summary, select, input, textarea, [contenteditable="true"], [role="button"], [data-gallery], img, video, picture, svg image, .project, .wh-card, .service-tile, .product-card, .journal-card, .review-card, .ch-card, .sh-icon, .kd-block-img';
  let x = -100, y = -100, raf = 0;
  const draw = () => { raf = 0; dot.style.transform = `translate3d(${x}px, ${y}px, 0)`; };
  addEventListener('mousemove', e => {
    x = e.clientX; y = e.clientY;
    dot.classList.add('on');
    if (!raf) raf = requestAnimationFrame(draw);
  }, {passive: true});
  document.addEventListener('mouseover', e => {
    const native = !!(e.target.closest && e.target.closest(NATIVE));
    root.classList.toggle('kd-native', native);
    dot.classList.toggle('away', native);
  });
  root.addEventListener('mouseleave', () => dot.classList.remove('on'));
  addEventListener('blur', () => dot.classList.remove('on'));
  addEventListener('mousedown', () => dot.classList.add('press'));
  addEventListener('mouseup', () => dot.classList.remove('press'));
})();
