/* Studio motion: progressive enhancement, no animation dependencies. */
(() => {
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = matchMedia('(hover: hover) and (pointer: fine)');
  let cleanup = () => {};
  function start() {
    cleanup();
    if (preference.matches || !Element.prototype.animate) return;
    const abort = new AbortController();
    const signal = abort.signal;
    const running = new Set();
    const observers = [];
    const extra = [];
    const media = [];
    const on = (target, name, fn, options = {}) => target.addEventListener(name, fn, {...options, signal});
    function animate(el, frames, options = {}) {
      const animation = el.animate(frames, {duration: 650, easing: 'cubic-bezier(.2,.7,.2,1)', ...options});
      running.add(animation);
      animation.onfinish = animation.oncancel = () => running.delete(animation);
      return animation;
    }
    document.body.classList.add('motion-enabled');
    // The first screen enters in a short, readable sequence.
    const entrance = document.querySelectorAll('.hero .eyebrow, .hero h1, .hero .lead, .hero .actions, .hero-bottom, .page-head .eyebrow, .page-head h1, .page-head p');
    entrance.forEach((el, i) => animate(el, [{opacity: 0, translate: '0 22px'}, {opacity: 1, translate: '0 0'}], {delay: Math.min(i, 4) * 75, duration: 700}));
    const art = document.querySelector('.art');
    if (art) {
      animate(art, [{opacity:0, translate:'24px 12px'}, {opacity:1, translate:'0 0'}], {duration:900, delay:150});
      const curve = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      curve.setAttribute('viewBox', '0 0 500 470');
      curve.setAttribute('class', 'motion-curve');
      curve.setAttribute('aria-hidden','true');
      curve.innerHTML='<path d="M25 345 C90 180 375 440 465 210" fill="none" stroke="#6c3bff" stroke-width="1.5" stroke-dasharray="650" stroke-dashoffset="650"/><g fill="var(--bg)" stroke="#6c3bff" stroke-width="1.5"><rect x="21" y="341" width="8" height="8"/><rect x="461" y="206" width="8" height="8"/></g>';
      art.prepend(curve); extra.push(curve);
      animate(curve.querySelector('path'), [{strokeDashoffset:650}, {strokeDashoffset:0}], {duration:1400, delay:400, fill:'forwards'});
      [['.canvas',-7,6,6200],['.cursor',8,-6,4800],['.sticker',-4,7,5600],['.swatches',3,-4,6500]].forEach(([selector,x,y,duration])=>{
        const el=art.querySelector(selector); if(!el)return;
        const a=animate(el,[{translate:'0 0'},{translate:`${x}px ${y}px`},{translate:'0 0'}],{duration,iterations:Infinity,easing:'ease-in-out'});media.push({el,a});
      });
    }
    // Reveal once per element, with card-level stagger. Nothing is hidden if JS fails.
    const seen = new WeakSet();
    const reveal = new IntersectionObserver(entries => entries.forEach(entry => {
      if(!entry.isIntersecting || seen.has(entry.target))return;
      const el=entry.target; seen.add(el); reveal.unobserve(el);
      const siblings = el.parentElement.matches('.grid3,.work-grid,.steps,.footgrid') ? [...el.parentElement.children] : [];
      const delay=siblings.length ? (siblings.indexOf(el)%3)*85 : 0;
      animate(el,[{opacity:0,translate:'0 30px'},{opacity:1,translate:'0 0'}],{duration:650,delay});
    }),{threshold:0.08,rootMargin:'0px 0px -25px 0px'});
    observers.push(reveal);
    const scan = root => {
      if(root.nodeType!==1)return;
      const selectors='.section-heading,.section>h2,.grid3>*,.work-grid>*,.steps>*,.two-col>*,.cta>*,.footgrid>*,.fresh-section>*,.playground-grid>*,.social-gallery>*,.reels-section>*,.reel-gallery>*,.about-company>*,.leadership-grid>*';
      if(root.matches(selectors))reveal.observe(root);
      root.querySelectorAll(selectors).forEach(el=>reveal.observe(el));
    };
    scan(document.querySelector('main')); scan(document.querySelector('footer'));
    // Newly rendered pricing cards and successful forms use the same motion system.
    const mutations=new MutationObserver(records=>records.forEach(r=>r.addedNodes.forEach(node=>{scan(node);if(node.nodeType===1&&node.matches('.booking-success'))animate(node,[{opacity:0,translate:'0 12px'},{opacity:1,translate:'0 0'}])})));
    mutations.observe(document.querySelector('main'),{childList:true,subtree:true});observers.push(mutations);
    const ticker=document.querySelector('.marquee');
    if(ticker){
      const original=ticker.textContent;
      const track=document.createElement('div');track.className='marquee-track';
      const one=document.createElement('span');one.textContent=original+'　';
      const two=one.cloneNode(true);two.setAttribute('aria-hidden','true');track.append(one,two);ticker.replaceChildren(track);
      const a=animate(track,[{transform:'translateX(0)'},{transform:'translateX(-50%)'}],{duration:35000,iterations:Infinity,easing:'linear'});media.push({el:ticker,a});
      on(ticker,'pointerenter',()=>a.pause());on(ticker,'pointerleave',()=>{if(!document.hidden)a.play()});
      extra.push(()=>{ticker.textContent=original});
    }
    // Pause continuous motion outside the viewport and when the tab is hidden.
    const visibility=new IntersectionObserver(entries=>entries.forEach(entry=>media.filter(m=>m.el===entry.target).forEach(m=>{m.visible=entry.isIntersecting;if(entry.isIntersecting&&!document.hidden)m.a.play();else m.a.pause()})));
    observers.push(visibility);media.forEach(m=>visibility.observe(m.el));
    on(document,'visibilitychange',()=>media.forEach(m=>document.hidden||m.visible===false?m.a.pause():m.a.play()));
    const progress=document.createElement('div');progress.className='reading-progress';progress.setAttribute('aria-hidden','true');document.body.append(progress);extra.push(progress);
    let frame=0;
    const update=()=>{frame=0;const distance=document.documentElement.scrollHeight-innerHeight;progress.style.scale=`${distance>0?scrollY/distance:0} 1`;document.querySelector('header').classList.toggle('scrolled',scrollY>20)};
    on(window,'scroll',()=>{if(!frame)frame=requestAnimationFrame(update)},{passive:true});update();
    if(finePointer.matches){
      document.querySelectorAll('.project-art').forEach(el=>{
        on(el,'pointermove',e=>{const r=el.getBoundingClientRect();el.style.setProperty('--tilt-x',`${-(e.clientY-r.top-r.height/2)/r.height*5}deg`);el.style.setProperty('--tilt-y',`${(e.clientX-r.left-r.width/2)/r.width*5}deg`)});
        on(el,'pointerleave',()=>{el.style.setProperty('--tilt-x','0deg');el.style.setProperty('--tilt-y','0deg')});
      });
      document.querySelectorAll('.hero .button,.cta .button').forEach(el=>{
        on(el,'pointermove',e=>{const r=el.getBoundingClientRect();el.style.translate=`${(e.clientX-r.left-r.width/2)*.055}px ${(e.clientY-r.top-r.height/2)*.07}px`});
        on(el,'pointerleave',()=>el.style.translate='');
      });
    }
    on(document,'click',e=>{
      const button=e.target.closest('button.chip,.format');
      if(button)animate(button,[{scale:1},{scale:.95},{scale:1}],{duration:230});
    });
    document.querySelectorAll('details').forEach(el=>on(el,'toggle',()=>{if(el.open)[...el.children].filter(c=>c.tagName!=='SUMMARY').forEach(c=>animate(c,[{opacity:0,translate:'0 -5px'},{opacity:1,translate:'0 0'}],{duration:260}))}));
    const projectNext=document.querySelector('#next'),projectPrev=document.querySelector('#prev');
    [projectNext,projectPrev].filter(Boolean).forEach(button=>on(button,'click',()=>{
      const step=document.querySelector('.form-step:not(.hidden)');
      if(step)animate(step,[{opacity:.3,translate:button===projectPrev?'-12px 0':'12px 0'},{opacity:1,translate:'0 0'}],{duration:300});
    }));
    if(location.pathname==='/thank-you'&&!sessionStorage.motionThanks){
      sessionStorage.motionThanks='1';
      const burst=document.createElement('div');burst.className='confetti';burst.setAttribute('aria-hidden','true');document.body.append(burst);extra.push(burst);
      for(let i=0;i<22;i++){const p=document.createElement('i');p.style.background=['#ff5a1f','#6c3bff','#ffd60a'][i%3];p.style.left=(20+Math.random()*60)+'%';burst.append(p);animate(p,[{translate:'0 -20px',rotate:'0deg',opacity:1},{translate:`${(Math.random()-.5)*160}px ${innerHeight*.7}px`,rotate:`${Math.random()*500}deg`,opacity:0}],{duration:1800+Math.random()*900,delay:Math.random()*250,fill:'forwards'})}
    }
    cleanup=()=>{abort.abort();observers.forEach(o=>o.disconnect());running.forEach(a=>a.cancel());extra.forEach(e=>typeof e==='function'?e():e.remove());cancelAnimationFrame(frame);document.body.classList.remove('motion-enabled');document.querySelectorAll('.project-art').forEach(el=>{el.style.removeProperty('--tilt-x');el.style.removeProperty('--tilt-y')});document.querySelectorAll('.hero .button,.cta .button').forEach(el=>el.style.translate='')};
  }
  preference.addEventListener('change',start);
  start();
})();
