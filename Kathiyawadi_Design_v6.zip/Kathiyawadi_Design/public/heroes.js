/* Animated hero sections for the Work and Contact pages (markup is in app.js). */
(() => {
  const q = s => document.querySelector(s), all = s => [...document.querySelectorAll(s)];
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Count-up numbers (Work hero)
  const counters = all('[data-count]');
  if (counters.length) {
    const run = el => {
      const end = Number(el.dataset.count) || 0;
      if (reduced) { el.textContent = String(end).padStart(2, '0'); return; }
      const t0 = performance.now(), dur = 1200;
      const step = t => { const k = Math.min(1, (t - t0) / dur); el.textContent = String(Math.round(end * (1 - Math.pow(1 - k, 3)))).padStart(2, '0'); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    };
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { run(e.target); io.unobserve(e.target); } }), {threshold: .4});
    counters.forEach(c => io.observe(c));
  }

  // Shuffling project deck (Work hero)
  const deck = q('.wh-deck');
  if (deck) {
    const cards = all('.wh-card');
    let order = cards.map((_, i) => i), timer = null, busy = false;
    const place = () => order.forEach((cardIndex, pos) => { cards[cardIndex].dataset.pos = pos; cards[cardIndex].tabIndex = pos === 0 ? 0 : -1; });
    const next = () => {
      if (busy || cards.length < 2) return;
      busy = true;
      const front = cards[order[0]];
      front.classList.add('wh-out');
      setTimeout(() => { order.push(order.shift()); front.classList.remove('wh-out'); place(); busy = false; }, reduced ? 0 : 520);
    };
    const start = () => { if (!reduced && !timer) timer = setInterval(next, 3200); };
    const stop = () => { clearInterval(timer); timer = null; };
    place();
    start();
    deck.addEventListener('mouseenter', stop);
    deck.addEventListener('mouseleave', start);
    deck.addEventListener('focusin', stop);
    deck.addEventListener('focusout', start);
    // A card behind the front one comes to the front instead of opening.
    cards.forEach(c => c.addEventListener('click', e => {
      if (c.dataset.pos === '0') return;
      e.preventDefault();
      while (cards[order[0]] !== c) order.push(order.shift());
      place();
    }));
    const shuffle = q('.wh-shuffle');
    if (shuffle) shuffle.addEventListener('click', next);
    document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
  }

  // Category chips jump to the filtered project list (Work hero)
  all('[data-jump]').forEach(b => b.addEventListener('click', () => {
    const filter = q(`[data-filter=${b.dataset.jumpFilter || 'work'}] button[data-value="${b.dataset.jump}"]`);
    if (filter) filter.click();
    all('[data-jump]').forEach(x => x.classList.toggle('active', x === b));
    const list = q(b.dataset.jumpTarget || '#work-list');
    if (list) list.scrollIntoView({behavior: reduced ? 'auto' : 'smooth', block: 'start'});
  }));

  // Services hero: chips and orbiting icons scroll to that service
  all('[data-goto]').forEach(b => b.addEventListener('click', () => {
    const t = document.getElementById(b.dataset.goto);
    if (b.dataset.role) { const sel = q('select[name=role]'); if (sel) sel.value = b.dataset.role; }
    if (t) t.scrollIntoView({behavior: reduced ? 'auto' : 'smooth', block: 'start'});
  }));
  const sw = q('.sh-words');
  if (sw && !reduced) {
    const words = sw.dataset.words.split('|');
    let k = 0;
    setInterval(() => {
      if (document.hidden) return;
      k = (k + 1) % words.length;
      sw.classList.add('swap');
      setTimeout(() => { sw.querySelector('b').textContent = words[k]; sw.classList.remove('swap'); }, 300);
    }, 2600);
  }

  // Rotating word (Contact hero)
  const rot = q('.ch-rotator');
  if (rot && !reduced) {
    const words = (rot.dataset.words || '').split('|').filter(Boolean);
    let i = 0;
    setInterval(() => {
      if (document.hidden || !words.length) return;
      i = (i + 1) % words.length;
      const out = rot.querySelector('span');
      const inn = document.createElement('span');
      inn.textContent = words[i];
      inn.className = 'ch-in';
      out.classList.add('ch-out');
      rot.append(inn);
      setTimeout(() => out.remove(), 500);
      requestAnimationFrame(() => requestAnimationFrame(() => inn.classList.remove('ch-in')));
    }, 2300);
  }

  // Live Ahmedabad clock (Contact hero)
  const clock = q('#ch-clock');
  if (clock) {
    const fmt = new Intl.DateTimeFormat('en-IN', {timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true});
    const tick = () => { clock.textContent = fmt.format(new Date()).toUpperCase(); };
    tick(); setInterval(tick, 15000);
  }

  // Chat conversation that types itself (Contact hero)
  const chat = q('.ch-messages');
  if (chat) {
    const lines = JSON.parse(chat.dataset.lines || '[]');
    const add = (who, text) => {
      const m = document.createElement('div');
      m.className = 'ch-msg ' + who;
      m.textContent = text;
      chat.append(m);
      while (chat.children.length > 6) chat.firstElementChild.remove();
      return m;
    };
    if (reduced) lines.forEach(l => add(l[0], l[1]));
    else {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      (async function play() {
        for (;;) {
          chat.innerHTML = '';
          for (const [who, text] of lines) {
            const typing = add(who + ' typing', '');
            typing.innerHTML = '<i></i><i></i><i></i>';
            await wait(who === 'them' ? 1100 : 800);
            typing.remove();
            add(who, text);
            await wait(900);
          }
          await wait(4200);
          while (document.hidden) await wait(1000);
        }
      })();
    }
  }

  // Contact quick starter: pick an idea, get a ready message for WhatsApp or the form
  const starter = q('.kd-starter');
  if (starter) {
    const open = q('#kd-open');
    const now = new Date(new Date().toLocaleString('en-US', {timeZone: 'Asia/Kolkata'}));
    const isOpen = now.getDay() !== 0 && now.getHours() >= 10 && now.getHours() < 18;
    open.classList.toggle('closed', !isOpen);
    open.querySelector('b').textContent = isOpen ? 'Open now · replies today' : 'Closed now · we reply next working day';
    const bubble = q('#kd-starter-bubble'), out = q('#kd-starter-text'), wa = q('#kd-starter-wa');
    let typing = 0, chosen = null;
    all('.kd-idea').forEach(b => b.addEventListener('click', () => {
      chosen = b;
      all('.kd-idea').forEach(x => x.classList.toggle('active', x === b));
      const text = b.dataset.text;
      wa.href = 'https://wa.me/919313780425?text=' + encodeURIComponent(text);
      bubble.hidden = false;
      bubble.classList.remove('pop'); void bubble.offsetWidth; bubble.classList.add('pop');
      clearInterval(typing);
      if (reduced) { out.textContent = text; return; }
      let i = 0; out.textContent = '';
      typing = setInterval(() => { out.textContent = text.slice(0, ++i); if (i >= text.length) clearInterval(typing); }, 14);
    }));
    q('#kd-starter-form').addEventListener('click', () => {
      if (!chosen) return;
      const radio = q(`input[name=subject][value="${chosen.dataset.subject}"]`);
      if (radio) { radio.checked = true; radio.dispatchEvent(new Event('change', {bubbles: true})); }
      const msg = q('#contact-message');
      if (msg) { msg.value = chosen.dataset.text; msg.dispatchEvent(new Event('input', {bubbles: true})); }
      const card = q('.contact-form-card');
      if (card) card.scrollIntoView({behavior: reduced ? 'auto' : 'smooth', block: 'start'});
      const name = q('.contact-form-card input[name=name]');
      if (name) setTimeout(() => name.focus({preventScroll: true}), reduced ? 0 : 600);
    });
  }

  // Magnetic hover on the contact cards (mouse only)
  if (!reduced && matchMedia('(pointer: fine)').matches) all('.ch-card').forEach(c => {
    c.addEventListener('mousemove', e => { const r = c.getBoundingClientRect(); c.style.setProperty('--mx', ((e.clientX - r.left) / r.width - .5) * 10 + 'px'); c.style.setProperty('--my', ((e.clientY - r.top) / r.height - .5) * 10 + 'px'); });
    c.addEventListener('mouseleave', () => { c.style.removeProperty('--mx'); c.style.removeProperty('--my'); });
  });
})();
