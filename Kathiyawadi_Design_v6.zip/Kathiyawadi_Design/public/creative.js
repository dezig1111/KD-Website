/* Interactive studio displays, campaign art and portrait motion samples. */
(() => {
 const q=s=>document.querySelector(s),all=s=>[...document.querySelectorAll(s)];
 const home=location.pathname==='/';
 const cafe='/media/cafe-campaign.webp';
 const socialPost=(theme='cafe',kind='polished')=>{
   if(kind==='before')return `<div class="social-art before-post"><div class="before-brand">SAVOR CAFE</div><div class="before-photo"><img src="${cafe}" alt="Coffee campaign photography" loading="lazy"></div><h3>Fresh coffee<br>every day!</h3><p>Visit us for your daily coffee.</p><span>OPEN DAILY · GOOD COFFEE</span></div>`;
   if(theme==='space')return `<div class="social-art space-post"><img src="/media/architecture.jpg" alt="Sunlit contemporary home with a garden" loading="lazy"><div class="post-topline">URBANEST <span>SPACES / 01</span></div><div class="space-copy"><small>A NEW WAY TO LIVE</small><strong>Find your<br>kind of space.</strong><span>Thoughtfully made. Beautifully yours. ↗</span></div></div>`;
   if(theme==='type')return `<div class="social-art type-post"><span class="post-topline">FORM / A DESIGN EXPLORATION</span><strong>Less,<br>but<br><em>better.</em></strong><div class="type-sculpture">✳</div><span class="type-caption">A LITTLE RESTRAINT.<br>A LOT OF CHARACTER. ↗</span></div>`;
   return `<div class="social-art cafe-post"><img src="${cafe}" alt="Art-directed ceramic espresso cup on a warm orange surface" loading="lazy"><div class="post-topline">SAVOR® <span>YOUR DAILY PAUSE.</span></div><div class="cafe-copy"><small>BREWED SLOW. ENJOYED FULLY.</small><strong>A little<br>pause.<br><em>A lot of soul.</em></strong></div><span class="post-bottom">GOOD COFFEE. BETTER CONVERSATIONS. ↗</span></div>`;
 };
 const uiVisual=()=>`<div class="ui-stage"><div class="ui-frame"><div class="ui-bar"><span>◉ ◉ ◉</span><small>finova / dashboard</small><span>↗</span></div><div class="ui-shell"><aside><b>f.</b><i>▦</i><i>↗</i><i>≋</i><i>⚙</i></aside><div class="ui-main"><span class="ui-eyebrow">A GOOD DAY TO GROW</span><h3>Your money.<br>In your corner.</h3><div class="ui-balance"><span>Total balance</span><strong>₹84,250<span>.00</span></strong><small>↗ +12.8% this month</small></div><div class="ui-chart" aria-label="Illustrative growth chart">${[35,50,42,68,56,78,65,93,83,100].map((x,i)=>`<i style="--bar:${x}%;--i:${i}"></i>`).join('')}</div><div class="ui-tiny-cards"><span>◉ Smart savings<br><b>₹12,500</b></span><span>↗ Your goals<br><b>Looking good.</b></span></div></div></div></div><span class="design-cursor">➤ <b>Viraj · Designing</b></span><div class="spacing-tag">↔ 24 px</div><div class="component-tag">◇ Balance / Default</div></div>`;
 const reelItems=[
  {id:'savor',title:'A moment, well brewed.',label:'SAVOR® / MOTION STUDY',type:'Brand reel',src:'/media/coffee-reel.mp4',poster:'/media/cafe-campaign.webp'},
  {id:'bloom',title:'A little closer to nature.',label:'IN BLOOM / EDITORIAL',type:'Editorial reel',src:'/media/bloom-reel.mp4',poster:'/media/flower-poster.jpg'},
  {id:'space',title:'Space to be yourself.',label:'URBANEST / SPATIAL STUDY',type:'Architecture reel',src:'/media/space-reel.mp4',poster:'/media/architecture.jpg'},
  {id:'matter',title:'Make every frame matter.',label:'MAKE IT MATTER / TYPE STUDY',type:'Typography reel',src:'/media/matter-reel.mp4',poster:'/media/matter-poster.jpg'},
  {id:'color',title:'A little outside the lines.',label:'COLOUR IN MOTION / STUDY',type:'Graphic motion reel',src:'/media/color-reel.mp4',poster:'/media/color-poster.jpg'}
 ];
 if(home){
   const art=q('.art');art.insertAdjacentHTML('beforeend',`<div class="hero-layers"><b>▱ Layers <i>⌘ K</i></b><b>◇ Big idea</b><b>▧ Visual direction</b><b>↗ Make it happen</b></div><div class="hero-comment"><span>✳</span><div>A little more personality?<b>Already on it. ↗</b></div></div>`);
   const compareSection=q('#comparison')?.closest('.section');
   if(compareSection){compareSection.classList.add('fresh-section');compareSection.id='fresh-view';compareSection.innerHTML=`<div class="fresh-intro"><div class="eyebrow">04 / A fresh point of view</div><h2>Same idea.<br>A whole new <em>feeling.</em></h2><p>It’s not just a post. It’s the moment someone stops scrolling.<br>Slide to see what a little creative direction can change.</p><div class="fresh-points"><span><b>01</b> A stronger visual story</span><span><b>02</b> Type that does the talking</span><span><b>03</b> A brand worth remembering</span></div><a class="button orange" href="/contact?service=Graphic">Give my brand a fresh view ↗</a><p class="muted">Illustrative concept · Drag, tap or use the arrow keys.</p></div><div class="fresh-display"><div class="frame-caption"><span>POST / 1080 × 1350</span><span>4:5 ↗</span></div><div class="post-comparison" style="--split:50%"><div class="comparison-base">${socialPost('cafe','before')}</div><div class="comparison-polished">${socialPost()}</div><div class="comparison-line"><span>↔</span></div><span class="comparison-label before">BEFORE</span><span class="comparison-label after">AFTER</span><input id="post-slider" type="range" min="0" max="100" value="50" aria-label="Reveal redesigned social media post"></div><div class="comparison-controls"><button class="chip" data-split="100">See the original</button><span>← DRAG TO TRANSFORM →</span><button class="chip" data-split="0">See the redesign</button></div></div>`;
     const slider=q('#post-slider');const set=v=>{slider.value=v;q('.post-comparison').style.setProperty('--split',v+'%');slider.setAttribute('aria-valuetext',`${100-Number(v)} percent redesign revealed`)};slider.oninput=e=>set(e.target.value);all('[data-split]').forEach(b=>b.onclick=()=>set(b.dataset.split));
   }
   const lab=document.createElement('section');lab.className='section design-lab';lab.innerHTML=`<div class="section-heading"><div><div class="eyebrow">05 / Inside the creative playground</div><h2>Pixels with purpose.<br>Personality included.</h2></div><p>Interfaces you want to use.<br>Visuals you want to save.</p></div><div class="playground-grid"><article class="playground-ui"><div class="playground-label"><span>01 / DIGITAL EXPERIENCES</span><a href="/services/ui-ux-design" aria-label="Explore UI/UX design">↗</a></div>${uiVisual()}<div class="playground-copy"><h3>Looks sharp. Feels effortless.</h3><p>From a rough wireframe to that “this just makes sense” moment.</p></div></article><article class="playground-graphic"><div class="playground-label"><span>02 / VISUAL IDENTITIES</span><a href="/services/graphic-design" aria-label="Explore graphic design">↗</a></div><div class="type-play"><span class="baseline">TYPE THAT TALKS.</span><div class="type-selection"><strong id="specimen">Aa</strong><i></i><i></i><i></i><i></i></div><div class="type-tools"><button data-font="sans" class="selected" aria-pressed="true">Grotesk</button><button data-font="serif" aria-pressed="false">Editorial</button><button data-font="mono" aria-pressed="false">Mono</button></div><div class="brand-palette"><button style="background:#6c3bff" aria-label="Set violet type" data-ink="#6c3bff"></button><button style="background:#ff5a1f" aria-label="Set orange type" data-ink="#d9430a"></button><button style="background:#171719" aria-label="Set black type" data-ink="#171719"></button></div><span class="palette-hint">↳ Pick a typeface. Add your personality.</span></div><div class="playground-copy"><h3>Every brand has a character.</h3><p>We make sure yours comes through. Down to the last letter.</p></div></article></div>`;
   lab.querySelector('.playground-grid').insertAdjacentHTML('beforeend',`<article class="playground-motion"><div class="playground-label"><span>03 / VIDEO EDITING</span><a href="/services/video-editing" aria-label="Explore video editing">↗</a></div><div class="motion-playground demo-playing"><div class="motion-preview"><small>THE CREATIVE CUT / 9:16</small><strong>Make<br>every<br><em>frame.</em></strong><span class="motion-orbit">✳</span><span class="motion-caption">A STORY WORTH WATCHING.</span></div><div class="motion-tracks"><i></i><i></i><i></i><b></b></div><button class="motion-demo-toggle" type="button" aria-pressed="true">Pause demo</button></div><div class="playground-copy"><h3>Find your rhythm.</h3><p>Sharp edits, thoughtful pacing and motion with a purpose.</p></div></article><article class="playground-social"><div class="playground-label"><span>04 / SOCIAL MEDIA DESIGN</span><a href="/services/graphic-design" aria-label="Explore social media design">↗</a></div><div class="social-playground"><div class="social-mini-post"><span>SAVOR® / CREATIVE STUDY</span><strong>A little<br>pause.</strong><img src="/media/cafe-campaign.webp" alt="Coffee social media campaign concept" loading="lazy"><small>MADE FOR YOUR DAILY SCROLL.</small></div><button class="social-demo-toggle" type="button">Next creative</button></div><div class="playground-copy"><h3>Give your feed a voice.</h3><p>Social posts and campaign visuals that feel unmistakably you.</p></div></article>`);
   q('.cta').before(lab);
   const social=document.createElement('section');social.className='section social-showcase';social.id='social-studio';social.innerHTML=`<div class="section-heading"><div><div class="eyebrow">06 / Made for the scroll. Built to be remembered.</div><h2>A feed with<br>a point of view.</h2></div><div><p>Campaigns, carousels and a little<br>well-designed main-character energy.</p><a href="/services/graphic-design" class="text-link">Explore graphic design ↗</a></div></div><div class="social-gallery"><article><div class="frame-caption"><span>01 / CAFE CAMPAIGN</span><span>4:5</span></div>${socialPost()}<h3>Your daily pause.</h3><p>Art direction · Social campaign</p></article><article><div class="frame-caption"><span>02 / REAL ESTATE</span><span>4:5</span></div>${socialPost('space')}<h3>A different kind of space.</h3><p>Photography-led · Brand storytelling</p></article><article><div class="frame-caption"><span>03 / TYPE EXPLORATION</span><span>4:5</span></div>${socialPost('type')}<h3>Say more with less.</h3><p>Typography · Graphic composition</p></article></div><p class="muted">Original illustrative campaigns. Photography is used for concept presentation, not as a claim of client work.</p>`;q('.cta').before(social);
   const reels=document.createElement('section');reels.className='section reels-section';reels.innerHTML=`<div class="reels-intro"><div class="eyebrow">07 / A little motion. A lot of emotion.</div><h2>Stop the scroll.<br><em>Start a story.</em></h2><p>Sharp cuts. Bold type. A rhythm that feels right.<br>Portrait-first ideas, made for the way people watch.</p><p class="reels-description">From product stories to social campaigns, we turn your ideas and footage into reels worth watching. Thoughtful editing, expressive motion, clear captions and carefully chosen sound bring your brand’s personality to every frame.</p><div class="reel-chips"><span>REELS</span><span>MOTION</span><span>9:16</span></div><a href="/services/video-editing" class="button orange">Let’s make it move ↗</a><p class="muted">Five demo reels · Selected reel plays silently.<br>Sample footage and original motion, not client showreels.</p></div><div class="reel-gallery reel-browser reel-coverflow" role="region" aria-label="Five concept reels"><div class="reel-stack" tabindex="0" aria-label="Reel carousel. Select a side reel, swipe, or use left and right arrow keys.">${[-2,-1,1,2].map(slot=>`<button class="reel-side reel-side-${slot}" type="button" data-reel-slot="${slot}" aria-controls="main-reel"><img alt="" loading="eager"><span class="reel-side-name"></span></button>`).join('')}<article class="reel-card reel-feature"><div class="reel-media"><video id="main-reel" controls playsinline loop muted preload="metadata" poster="${reelItems[0].poster}" aria-label="${reelItems[0].title}"><source src="${reelItems[0].src}" type="video/mp4"></video><span class="reel-corner" id="reel-corner">${reelItems[0].label}</span><div class="bloom-overlay" id="selected-bloom" hidden><small>A LITTLE MOMENT OF</small><strong>in<br>bloom.</strong><span>PAUSE. LOOK CLOSER.</span></div></div></article></div><div class="reel-meta reel-active-meta"><b id="reel-title">${reelItems[0].title}</b><span id="reel-type">${reelItems[0].type} / 9:16</span></div><p id="reel-status" class="reel-status" role="status" aria-live="polite"></p><p class="reel-stack-hint">Tap a side reel or swipe to bring it into focus.</p></div>`;q('.cta').before(reels);
 }
 // Real photography and UI mockups give portfolio cards context.
 all('.project').forEach(card=>{let slug=card.getAttribute('href').split('/').pop(),art=card.querySelector('.project-art');if(!art||art.classList.contains('has-photo'))return;
   if(['savor','chai-chowk'].includes(slug)){art.innerHTML=socialPost();art.classList.add('photo-project','portrait-project')}
   else if(['orivelle','urbanest'].includes(slug)){art.innerHTML=socialPost('space');art.classList.add('photo-project','portrait-project')}
   else if(['finova','pulse','brightpath'].includes(slug)){art.innerHTML=uiVisual();art.classList.add('ui-project')}
   else if(slug==='makers'){art.innerHTML=socialPost('type');art.classList.add('photo-project','portrait-project')}
 });
 // Portrait video project previews link through to playable case studies.
 all('.project[data-category=Video]').forEach(card=>{const art=card.querySelector('.project-art');if(!art||art.classList.contains('has-photo'))return;const space=card.href.includes('urbanest');art.classList.add('reel-project');art.classList.remove('portrait-project');art.innerHTML=`<img class="video-cover" src="${space?'/media/architecture.jpg':'/media/flower-poster.jpg'}" alt="${space?'Architectural motion study':'Nature editorial motion study'}" loading="lazy"><span class="project-play">▶</span><div class="project-reel-title"><small>CONCEPT MOTION / 9:16</small><strong>${space?'Space to<br>be yourself.':'A little<br>in bloom.'}</strong></div>`;if(location.pathname.startsWith('/work/')){const figure=document.createElement('figure');figure.className='case-reel';figure.innerHTML=`<video controls playsinline loop preload="none" poster="${space?'/media/architecture.jpg':'/media/flower-poster.jpg'}" aria-label="Play concept video"><source src="${space?'/media/space-reel.mp4':'/media/bloom-reel.mp4'}" type="video/mp4"></video><figcaption>Concept motion study · Silent preview · 9:16</figcaption>`;card.after(figure)}});
 // Compact, distinct design tools inside the three service cards.
 all('.service .icon').forEach((el,i)=>{const type=i%3;el.classList.add('tool-visual');el.innerHTML=type===0?'<div class="mini-window"><i></i><i></i><i></i><div><b></b><span></span><span></span><span></span></div><small>↖ Auto layout</small></div>':type===1?'<div class="mini-pen"><svg viewBox="0 0 250 90" aria-hidden="true"><path d="M20 65 C75 -30 175 120 230 25"/><rect x="16" y="61" width="8" height="8"/><rect x="226" y="21" width="8" height="8"/></svg><span>Aa<span>✳</span></span></div>':'<div class="mini-timeline"><span>▶</span><div><i></i><i></i><i></i></div><b></b><small>00:00:08:12</small></div>'});
 all('[data-font]').forEach(b=>b.onclick=()=>{q('#specimen').style.fontFamily={sans:'Space Grotesk, sans-serif',serif:'Georgia, serif',mono:'monospace'}[b.dataset.font];all('[data-font]').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',x===b)})});
 all('[data-ink]').forEach(b=>b.onclick=()=>q('#specimen').style.color=b.dataset.ink);
 // All default video previews are portrait, with a locally hosted demo file.
 const preview=q('#format-preview');if(preview){preview.src='/media/bloom-reel.mp4';preview.style.aspectRatio='9 / 16';preview.style.maxWidth='320px';preview.style.display='block';preview.style.margin='auto';preview.poster='/media/flower-poster.jpg';all('.format').forEach(b=>b.classList.toggle('selected',b.dataset.ratio==='9/16'))}
 // Compact gallery previews; full artwork is reserved for the project route.
 all('.work-grid .project').forEach(card=>{const art=card.querySelector('.project-art');if(!art||art.classList.contains('has-photo'))return;const stage=document.createElement('div');stage.className='thumbnail-stage';while(art.firstChild)stage.append(art.firstChild);art.append(stage);card.classList.add('compact-project');card.setAttribute('aria-label','View project: '+card.querySelector('h3').textContent);const hint=document.createElement('span');hint.className='thumbnail-hint';hint.textContent=card.dataset.category==='Video'?'View reel ↗':'View project ↗';art.append(hint)});
 if(location.pathname.startsWith('/work/')){document.body.classList.add('project-detail');const card=q('.project');if(card){const article=document.createElement('article');article.className=card.className;article.dataset.category=card.dataset.category;while(card.firstChild)article.append(card.firstChild);card.replaceWith(article);if(article.dataset.category==='Video'&&!article.querySelector('.project-art.has-photo'))article.querySelector('.project-art').hidden=true}}
 // Artboard loop: cycle actual layer rows and swatch colors without moving the panels.
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const layerBox=q('.hero-layers');
 if(layerBox){layerBox.classList.add('cycling-layers');layerBox.querySelectorAll(':scope>b').forEach((row,i)=>row.classList.add('layer-slot-'+i))}
 const swatchBox=q('.art .swatches');let swapping=false;
 const cycle=()=>{if(reduced.matches||document.hidden||!q('.art')?.classList.contains('creative-in-view'))return;
  if(layerBox){const rows=[...layerBox.querySelectorAll(':scope>b')];rows.forEach((row,i)=>{row.className='layer-slot-'+((i+1)%rows.length)});layerBox.insertBefore(rows[rows.length-1],rows[0])}
  if(swatchBox&&!swapping){
   const blocks=[...swatchBox.querySelectorAll('button')];if(blocks.length<2)return;
   swapping=true;const width=blocks[0].getBoundingClientRect().width;
   const last=blocks[blocks.length-1];
   const shifts=blocks.slice(0,-1).map(block=>block.animate([{transform:'translateX(0)'},{transform:`translateX(${width}px)`}],{duration:650,easing:'cubic-bezier(.22,.7,.2,1)',fill:'forwards'}));
   const wrap=last.animate([{transform:'translate(0,0)',offset:0},{transform:'translate(0,-27px)',offset:.23},{transform:`translate(${-width*(blocks.length-1)}px,-27px)`,offset:.77},{transform:`translate(${-width*(blocks.length-1)}px,0)`,offset:1}],{duration:650,easing:'ease-in-out',fill:'forwards'});
   Promise.all([...shifts,wrap].map(a=>a.finished.catch(()=>{}))).then(()=>{swatchBox.insertBefore(last,blocks[0]);[...shifts,wrap].forEach(a=>a.cancel());swapping=false});
  }
 };setInterval(cycle,2400);
 all('.mini-timeline').forEach(t=>{const icon=t.querySelector(':scope>span');icon.textContent='';icon.innerHTML='<i class="transport-play">▶</i><i class="transport-pause">Ⅱ</i>';t.classList.add('transport-loop');t.setAttribute('aria-label','Looping play, pause and timeline demonstration');t.setAttribute('role','img')});
 const freshButton=q('#fresh-view .button');if(freshButton)freshButton.textContent='Give my brand a fresh view';
 // Match each thumbnail to its card edge; keep the complete aspect ratio.
 const sizeThumb=art=>{const stage=art.querySelector('.thumbnail-stage');if(stage){const width=art.classList.contains('reel-project')?281.25:art.classList.contains('ui-project')?500:400;art.style.setProperty('--thumb-scale',art.clientWidth/width)}};
 const thumbObserver=new ResizeObserver(entries=>entries.forEach(e=>sizeThumb(e.target)));all('.work-grid .project-art').forEach(art=>{thumbObserver.observe(art);sizeThumb(art)});
 // Center reel stays clear; two softly blurred previews sit on each side.
 const mainReel=q('#main-reel');
 if(mainReel){
  const stack=q('.reel-stack'),sides=all('[data-reel-slot]'),status=q('#reel-status');
  let selected=0,inView=false,userPaused=false,expectedPause=false,gesture=null,wheelAt=0;
  mainReel.dataset.autoloop='true';mainReel.muted=true;
  const pause=()=>{if(!mainReel.paused){expectedPause=true;mainReel.pause()}};
  const play=()=>{const attempt=mainReel.play();if(attempt)attempt.catch(()=>{if(inView&&!document.hidden)status.textContent='Press play to start this reel.'})};
  const sync=()=>{if(inView&&!document.hidden&&!userPaused&&!reduced.matches)play();else pause()};
  mainReel.addEventListener('pause',()=>{if(expectedPause){expectedPause=false;return}if(inView&&!document.hidden)userPaused=true});
  mainReel.addEventListener('play',()=>{userPaused=false;status.textContent='';if(!inView||document.hidden)pause()});
  const renderSides=()=>sides.forEach(button=>{const slot=Number(button.dataset.reelSlot),index=(selected+slot+reelItems.length)%reelItems.length,r=reelItems[index];button.dataset.reelIndex=index;button.setAttribute('aria-label','Play '+r.title+' Bring reel '+(index+1)+' to the front.');button.querySelector('img').src=r.poster;button.querySelector('.reel-side-name').textContent=r.type});
  const select=index=>{const next=(index+reelItems.length)%reelItems.length;if(next===selected)return;pause();selected=next;userPaused=false;const r=reelItems[selected];status.textContent='';mainReel.poster=r.poster;mainReel.setAttribute('aria-label',r.title);mainReel.querySelector('source').src=r.src;mainReel.muted=true;mainReel.load();q('#reel-title').textContent=r.title;q('#reel-type').textContent=r.type+' / 9:16';q('#reel-corner').textContent=r.label;q('#selected-bloom').hidden=r.id!=='bloom';renderSides();if(inView&&!document.hidden)play()};
  sides.forEach(button=>button.onclick=()=>select(Number(button.dataset.reelIndex)));renderSides();
  stack.addEventListener('keydown',e=>{if(e.target.closest('video'))return;if(['ArrowRight','ArrowLeft','Home','End'].includes(e.key)){e.preventDefault();select(e.key==='Home'?0:e.key==='End'?4:selected+(e.key==='ArrowRight'?1:-1))}});
  stack.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')gesture={x:e.clientX,y:e.clientY,id:e.pointerId}});
  stack.addEventListener('pointerup',e=>{if(!gesture||gesture.id!==e.pointerId)return;const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y;gesture=null;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.4){select(selected+(dx<0?1:-1));stack.dataset.swiped='true';setTimeout(()=>delete stack.dataset.swiped,200)}});
  stack.addEventListener('pointercancel',()=>gesture=null);
  stack.addEventListener('click',e=>{if(stack.dataset.swiped){e.stopImmediatePropagation();e.preventDefault()}},true);
  stack.addEventListener('wheel',e=>{const delta=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:(e.shiftKey?e.deltaY:0);if(Math.abs(delta)>12){e.preventDefault();if(Date.now()-wheelAt>550){wheelAt=Date.now();select(selected+(delta>0?1:-1))}}},{passive:false});
  new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;sync()},{threshold:.35}).observe(mainReel);
  document.addEventListener('visibilitychange',sync);reduced.addEventListener('change',sync);
  mainReel.addEventListener('error',()=>status.textContent='Preview unavailable. Choose another reel or try again.',true);
 }
 // Erase and retype the specimen, with a new ink color on every pass.
 const specimen=q('#specimen');if(specimen){
  const inks=['#6c3bff','#d9430a','#171719'];let ink=0,typingVisible=false,tick=0;
  specimen.setAttribute('aria-label','Aa typography specimen');specimen.classList.add('typing-specimen');
  const typingObserver=new IntersectionObserver(entries=>typingVisible=entries[0].isIntersecting,{threshold:.25});typingObserver.observe(specimen);
  setInterval(()=>{if(reduced.matches||document.hidden||!typingVisible)return;tick=(tick+1)%18;
   if(tick===8)specimen.textContent='A';if(tick===9)specimen.textContent='';if(tick===11){ink=(ink+1)%inks.length;specimen.style.color=inks[ink];specimen.textContent='A'}if(tick===12)specimen.textContent='Aa';
  },180);
  reduced.addEventListener('change',()=>{if(reduced.matches)specimen.textContent='Aa'});
 }
 // Remove directional arrows from every boxed CTA, including dynamic/i18n labels.
 const cleanButton=button=>{if(!button.matches('.button,button:not(.plain)'))return;
  const walker=document.createTreeWalker(button,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
  nodes.forEach(n=>{const clean=n.textContent.replace(/[↗↖←→↘↙]/g,'').replace(/\s{2,}/g,' ');if(clean!==n.textContent)n.textContent=clean});
  button.querySelectorAll('span').forEach(s=>{if(!s.textContent.trim()&&!s.children.length)s.remove()});
 };
 all('.button,button:not(.plain)').forEach(cleanButton);
 const buttonChanges=new MutationObserver(records=>{const found=new Set();records.forEach(r=>{const node=r.target.nodeType===1?r.target:r.target.parentElement;const parent=node?.closest('.button,button:not(.plain)');if(parent)found.add(parent);r.addedNodes.forEach(n=>{if(n.nodeType===1){if(n.matches('.button,button:not(.plain)'))found.add(n);n.querySelectorAll('.button,button:not(.plain)').forEach(b=>found.add(b))}})});found.forEach(cleanButton)});
 buttonChanges.observe(document.body,{childList:true,subtree:true,characterData:true});
 // Service playground controls.
 const motionToggle=q('.motion-demo-toggle');if(motionToggle)motionToggle.onclick=()=>{const demo=q('.motion-playground');const playing=demo.classList.toggle('demo-playing');motionToggle.textContent=playing?'Pause demo':'Play demo';motionToggle.setAttribute('aria-pressed',playing)};
 const socialToggle=q('.social-demo-toggle');if(socialToggle){let variant=0;const variants=[['A little<br>pause.','#a53214'],['Brewed<br>for you.','#453388'],['Good days.<br>Great coffee.','#254c3d']];socialToggle.onclick=()=>{variant=(variant+1)%variants.length;const post=q('.social-mini-post');post.querySelector('strong').innerHTML=variants[variant][0];post.style.backgroundColor=variants[variant][1]}};
 // Twenty rotating lines: type, hold five seconds, erase, then advance.
 const footerLines=[
 'Good design. Lasting impressions.',
 'Bold ideas. Beautifully made.',
 'Local roots. Global vision.',
 'Small details. Big difference.',
 'Fresh thinking. Clear direction.',
 'Great stories. Better design.',
 'Your vision. Our creative spark.',
 'Thoughtful design. Real character.',
 'Less ordinary. More you.',
 'Clear purpose. Strong presence.',
 'One idea. Endless possibilities.',
 'Creative minds. Meaningful work.',
 'Distinctive brands. Lasting value.',
 'Sharp visuals. Strong stories.',
 'A little bold. A lot of soul.',
 'Made with care. Built to connect.',
 'Ideas that move. Design that stays.',
 'Fresh perspectives. Familiar soul.',
 'From first spark. To final detail.',
 'Rooted in craft. Ready for tomorrow.'
 ];
 const footerGujarati=[
 'સરસ ડિઝાઇન. કાયમી છાપ.','દમદાર વિચારો. સુંદર સર્જન.','સ્થાનિક મૂળ. વૈશ્વિક દૃષ્ટિ.','નાની વિગતો. મોટો ફરક.','નવા વિચારો. સ્પષ્ટ દિશા.','સરસ વાર્તાઓ. સુંદર ડિઝાઇન.','તમારી દૃષ્ટિ. અમારી સર્જનશક્તિ.','વિચારપૂર્વકની ડિઝાઇન. આગવી ઓળખ.','ઓછી સામાન્યતા. વધુ તમારી ઓળખ.','સ્પષ્ટ હેતુ. મજબૂત હાજરી.','એક વિચાર. અનંત શક્યતાઓ.','સર્જનાત્મક મન. અર્થપૂર્ણ કામ.','આગવી બ્રાન્ડ. કાયમી મૂલ્ય.','આકર્ષક દૃશ્યો. મજબૂત વાર્તાઓ.','થોડી હિંમત. ઘણો આત્મા.','કાળજીથી બનાવ્યું. જોડાણ માટે સર્જ્યું.','ગતિશીલ વિચારો. કાયમી ડિઝાઇન.','નવો દૃષ્ટિકોણ. પરિચિત આત્મા.','પહેલી ચમકથી. છેલ્લી વિગત સુધી.','કળામાં મૂળ. આવતીકાલ માટે તૈયાર.'
 ];
 const wordmark=q('footer .wordmark');if(wordmark){
  const lines=()=>document.documentElement.lang==='gu'?footerGujarati:footerLines;
  wordmark.textContent='';wordmark.setAttribute('aria-live','off');
  const measure=document.createElement('span');measure.className='footer-type-measure footer-lines-measure';measure.setAttribute('aria-hidden','true');
  const ink=document.createElement('span');ink.className='footer-type-ink';ink.setAttribute('aria-hidden','true');wordmark.append(measure,ink);
  const toggle=document.createElement('button');toggle.type='button';toggle.className='plain footer-lines-toggle';toggle.textContent='Pause changing line';toggle.setAttribute('aria-pressed','false');wordmark.after(toggle);
  let visible=false,index=0,letter=0,phase='write',hold=0,paused=false;
  const size=()=>{measure.replaceChildren(...lines().map(line=>{const span=document.createElement('span');span.textContent=line;return span}))};size();
  const phrase=()=>lines()[index];const label=()=>wordmark.setAttribute('aria-label',phrase());label();
  const next=()=>{index=(index+1)%lines().length;letter=0;label();phase=reduced.matches?'hold':'write';hold=0;ink.textContent=reduced.matches?phrase():''};
  if(reduced.matches){ink.textContent=phrase();phase='hold'}
  toggle.onclick=()=>{paused=!paused;if(paused){letter=phrase().length;ink.textContent=phrase();phase='hold';hold=0}toggle.textContent=paused?'Resume changing line':'Pause changing line';toggle.setAttribute('aria-pressed',paused)};
  new IntersectionObserver(entries=>visible=entries[0].isIntersecting,{threshold:.1}).observe(wordmark);
  setInterval(()=>{if(!visible||document.hidden||paused)return;const line=phrase();if(phase==='hold'){hold+=65;if(hold>=5000){if(reduced.matches)next();else phase='erase'}return}if(phase==='erase'){letter=Math.max(0,letter-2);ink.textContent=line.slice(0,letter);if(!letter)next();return}letter++;ink.textContent=line.slice(0,letter);if(letter>=line.length){phase='hold';hold=0}},65);
  reduced.addEventListener('change',()=>{letter=phrase().length;ink.textContent=phrase();phase='hold';hold=0});
  new MutationObserver(()=>{size();label();letter=phrase().length;ink.textContent=phrase();phase='hold';hold=0}).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 }
 // Respect visitors' playback choices; pause media when it leaves the screen.
 const artObserver=new IntersectionObserver(entries=>entries.forEach(e=>e.target.classList.toggle('creative-in-view',e.isIntersecting)),{threshold:.05});all('.art,.service,.ui-stage,.type-post,.playground-motion,.playground-social').forEach(el=>artObserver.observe(el));document.addEventListener('visibilitychange',()=>document.body.classList.toggle('creative-paused',document.hidden));
 const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(!e.isIntersecting&&e.target.dataset.autoloop!=='true')e.target.pause()}),{threshold:.1});all('video').forEach(v=>observer.observe(v));
 all('.reel-media video').forEach(v=>{v.addEventListener('error',()=>{const note=document.createElement('p');note.className='video-error';note.textContent='Preview unavailable. Please try again shortly.';v.after(note)},true)});
})();
