/* Official logo intro: first visit and refresh, without holding navigation or forms. */
(() => {
 const root=document.documentElement,overlay=document.getElementById('brand-intro');
 if(!overlay)return;
 const content=[...document.body.children].filter(e=>e!==overlay&&e.tagName!=='SCRIPT');
 let closed=false,fallback;
 const release=()=>{if(closed)return;closed=true;clearTimeout(fallback);root.classList.remove('brand-intro-active');content.forEach(e=>{if(e.dataset.brandInert==='true'){e.inert=false;delete e.dataset.brandInert}});overlay.remove();try{sessionStorage.setItem('kd:brand-seen','1')}catch{}};
 if(!root.classList.contains('brand-intro-active')){overlay.remove();return}
 content.forEach(e=>{if(!e.inert){e.inert=true;e.dataset.brandInert='true'}});
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const finish=()=>{if(closed)return;overlay.classList.add('brand-intro-exit');setTimeout(release,reduced?0:450)};
 fallback=setTimeout(release,3000);
 const image=overlay.querySelector('img');
 const ready=image.decode?image.decode().catch(()=>{}):Promise.resolve();
 ready.then(()=>setTimeout(finish,reduced?180:1900));
 addEventListener('pageshow',event=>{if(event.persisted)release()});
})();
