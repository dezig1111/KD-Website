/* Unique editorial artboards for each page, rather than a repeated home graphic. */
(() => {
 const header=document.querySelector('.page-head');if(!header)return;
 const path=location.pathname.replace(/\/$/,'')||'/';
 const content={
 '/about':['studio-story.fig','ROOTED HERE. READY FOR EVERYWHERE.','Local soul.\nGlobal outlook.','Saurashtra → Ideas → Everywhere','story',['Warmth','Character','Craft']],
 '/services':['creative-toolkit.fig','THREE CRAFTS. ONE STUDIO.','Every idea.\nThe right tools.','UI/UX + Graphics + Motion','tools',['Digital','Identity','Motion']],
 '/services/ui-ux-design':['digital-experience.fig','DESIGNED AROUND PEOPLE.','A good flow.\nA better feeling.','Research → Prototype → Refine','ui',['Research','Prototype','Handoff']],
 '/services/graphic-design':['brand-expression.ai','CHARACTER IN EVERY DETAIL.','Make your\nmark matter.','Type + Color + Character','brand',['Typography','Palette','Identity']],
 '/services/video-editing':['motion-study.prproj','THE STORY IS IN THE CUT.','Find the rhythm.\nMake it move.','00:00:08:12 / Creative cut','video',['Cut','Color','Sound']],
 '/work':['selected-explorations.fig','A FEW DIFFERENT POINTS OF VIEW.','Less explaining.\nMore exploring.','Concepts / Digital / Brand / Motion','work',['Digital','Campaigns','Motion']],
 '/process':['from-brief-to-brilliant.fig','CLARITY AT EVERY MILESTONE.','A little method.\nA lot of magic.','Discover → Design → Deliver','process',['Discover','Design','Deliver']],
 '/pricing':['creative-investment.fig','A SCOPE THAT FITS YOUR AMBITION.','Big ideas.\nClear plans.','Scope first. Surprises never.','pricing',['Scope','Timeline','Quote']],
 '/team':['the-creative-circle.fig','GOOD PEOPLE. DIFFERENT PERSPECTIVES.','Many minds.\nOne direction.','A shared eye for the details','team',['Ideas','Collaboration','Craft']],
 '/testimonials':['the-next-chapter.fig','GOOD WORK EARNS GOOD WORDS.','Make something\nworth talking about.','Your story could be next','reviews',['Thoughtful','Collaborative','Memorable']],
 '/blog':['studio-notebook.fig','NOTES FROM THE CREATIVE DESK.','Curious minds.\nFresh perspectives.','Ideas to keep. Notes to share.','journal',['Read','Learn','Explore']],
 '/start-project':['your-next-big-idea.fig','EVERY GOOD PROJECT STARTS HERE.','A blank canvas.\nYour next big thing.','Brief → Scope → Let’s create','brief',['Your idea','Your goals','Our craft']],
 '/book-a-call':['a-good-conversation.fig','THIRTY MINUTES. NEW POSSIBILITIES.','Bring the idea.\nLet’s find the way.','30 min / Discovery / IST','calendar',['Choose a day','Pick a time','Let’s talk']],
 '/careers':['your-next-chapter.fig','MORE PERSPECTIVES. BETTER IDEAS.','Your talent.\nOur next chapter.','Design + Curiosity + Collaboration','team',['Portfolio','Potential','Personality']],
 '/faq':['a-little-clarity.fig','GOOD QUESTIONS DESERVE CLEAR ANSWERS.','Less wondering.\nMore clarity.','The details, thoughtfully explained','faq',['Scope?','Timelines?','Files?']],
 '/contact':['a-simple-hello.fig','GOOD CONVERSATIONS START SMALL.','One hello.\nEndless possibilities.','Ahmedabad → Your next idea','contact',['Say hello','Share an idea','Let’s create']],
 '/privacy':['your-trust-matters.fig','CARE IS PART OF THE DESIGN.','Your information.\nHandled thoughtfully.','Clarity / Respect / Your choices','legal',['Information','Purpose','Choices']],
 '/terms':['a-clear-understanding.fig','GREAT WORK STARTS WITH CLARITY.','Clear expectations.\nBetter collaboration.','Scope / Milestones / Agreement','legal',['Scope','Ownership','Agreement']],
 '/thank-you':['a-new-beginning.fig','DHANYAVAAD. WE’VE GOT YOUR BRIEF.','The first step.\nA fresh beginning.','Your request is saved','thanks',['Received','Review','Next steps']]
 };
 let c=content[path];
 if(!c&&path.startsWith('/work/'))c=['behind-the-project.fig','THE THINKING BEHIND THE WORK.','From first spark\nto final detail.','Concept / Approach / Creative direction','work',['Challenge','Approach','Solution']];
 if(!c&&path.startsWith('/team/'))c=['meet-the-creative.fig','A PERSON BEHIND EVERY PIXEL.','A point of view.\nA shared purpose.','The creative circle / Studio profile','team',['Journey','Perspective','Craft']];
 if(!c&&(path==='/products'||path.startsWith('/products/')))c=['studio-shelf.fig','READY-MADE. MADE WITH CARE.','Good design,\nready to use.','Studio products / Templates & packs','work',['Templates','Packs','Print']];
 if(!c&&path.startsWith('/blog/'))c=['a-studio-perspective.fig','A LITTLE CREATIVE FOOD FOR THOUGHT.','Read a little.\nSee it differently.','Studio notes / Design thinking','journal',['Insight','Practice','Perspective']];
 if(!c)c=['outside-the-artboard.fig','EVERY EXPLORATION NEEDS A WAY HOME.','A little lost?\nLet’s reframe.','This frame is outside the canvas','missing',['Explore','Reframe','Home']];
 const symbols={story:'↗',tools:'✥',ui:'⌘',brand:'Aa',video:'▶',work:'▧',process:'→',pricing:'₹',team:'✳',reviews:'“',journal:'Aa',brief:'◇',calendar:'30',faq:'?',contact:'↗',legal:'✓',thanks:'✳',missing:'404'};
 const motif={
 ui:'<div class="pa-ui"><span></span><div><i></i><i></i><i></i></div><b></b><b></b></div>',
 brand:'<div class="pa-brand"><strong>Aa</strong><div><i></i><i></i><i></i></div><span>FORM / FEELING / IDENTITY</span></div>',
 video:'<div class="pa-video"><span>▶</span><i></i><i></i><i></i><b></b><small>00:00:08:12</small></div>',
 process:'<div class="pa-process"><span>01<br><b>Discover</b></span><span>02<br><b>Design</b></span><span>03<br><b>Deliver</b></span></div>',
 calendar:'<div class="pa-calendar"><span>LET’S FIND A GOOD DAY</span><div>'+Array.from({length:14},(_,i)=>'<b'+(i===8?' class="picked"':'')+'>'+(i+1)+'</b>').join('')+'</div></div>',
 team:'<div class="pa-team"><span>V</span><span>kp.</span><span>✳</span></div>',
 work:'<div class="pa-work"><img src="/media/cafe-campaign.webp" alt=""><img src="/media/architecture.jpg" alt=""><span>⌘<small>DIGITAL / BRAND / MOTION</small></span></div>',
 pricing:'<div class="pa-plans"><span>01<b>Starter</b><i></i></span><span>02<b>Growth</b><i></i><i></i></span><span>03<b>Premium</b><i></i><i></i><i></i></span></div>',
 journal:'<div class="pa-paper"><span>STUDIO NOTES / 01</span><strong>A new<br>perspective.</strong><i></i><i></i><i></i></div>',
 brief:'<div class="pa-brief"><span>YOUR NEXT BIG THING</span><i></i><i></i><div>◇ &nbsp; UI/UX &nbsp; ✳ &nbsp; GRAPHIC &nbsp; ▶</div></div>',
 faq:'<div class="pa-faq"><span>What if…? <b>+</b></span><span>How do we…? <b>−</b></span><i>Let’s make it clear.</i><span>Where next? <b>+</b></span></div>',
 contact:'<div class="pa-message"><span>Kem cho? ✳</span><span>Let’s make something great. ↗</span><i>● ● ●</i></div>',
 legal:'<div class="pa-checks"><span>✓ Clear information</span><span>✓ Thoughtful choices</span><span>✓ Shared understanding</span></div>',
 thanks:'<div class="pa-received"><span>✓</span><b>BRIEF RECEIVED.</b><small>A good beginning.</small></div>',
 reviews:'<div class="pa-quote"><strong>“</strong><span>Good work makes<br>a lasting impression.</span></div>',
 story:'<div class="pa-story"><span>GUJARAT</span><i>↗</i><strong>A world<br>of possibilities.</strong></div>',
 tools:'<div class="pa-tools"><span>⌘<b>UI/UX</b></span><span>✳<b>GRAPHIC</b></span><span>▶<b>MOTION</b></span></div>',
 missing:'<div class="pa-missing">404<span>FRAME NOT FOUND</span></div>'
 };
 const copy=document.createElement('div');copy.className='page-intro';while(header.firstChild)copy.append(header.firstChild);header.append(copy);
 const art=document.createElement('aside');art.className='page-art page-art-'+c[4];art.setAttribute('aria-hidden','true');
 art.innerHTML='<div class="pa-orbit"></div><div class="pa-board"><div class="pa-chrome"><span>◉ ◉ ◉</span><small></small></div><div class="pa-content"><span class="pa-eyebrow"></span><strong class="pa-headline"></strong>'+(motif[c[4]]||'')+'<div class="pa-tags"></div></div></div><span class="pa-star">'+symbols[c[4]]+'</span><div class="pa-note"></div><span class="pa-cursor">➤ <b>Creative mode</b></span>';
 art.querySelector('.pa-chrome small').textContent=c[0];art.querySelector('.pa-eyebrow').textContent=c[1];art.querySelector('.pa-headline').textContent=c[2];art.querySelector('.pa-note').textContent=c[3];c[5].forEach((t,i)=>{const tag=document.createElement('span');tag.textContent=t;tag.style.setProperty('--tag-index',i);art.querySelector('.pa-tags').append(tag)});header.append(art);header.classList.add('with-page-art');
 const observer=new IntersectionObserver(entries=>entries.forEach(e=>e.target.classList.toggle('pa-visible',e.isIntersecting)),{threshold:.05});observer.observe(art);
 document.addEventListener('visibilitychange',()=>art.classList.toggle('pa-paused',document.hidden));
})();
