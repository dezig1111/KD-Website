// Photos and videos uploaded from the admin panel. Files are saved in the database
// in 768 KB pieces (works the same in PostgreSQL and MongoDB, no extra storage needed)
// and served at /uploads/<id>.<ext> with Range support so videos can seek.
import crypto from 'node:crypto';
import {Readable} from 'node:stream';
import {IMAGE_TYPES, VIDEO_TYPES, MAX_IMAGE_MB, MAX_VIDEO_MB, CHUNK_BYTES} from './media-slots.js';

const EXT = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif', 'video/mp4': 'mp4', 'video/webm': 'webm'};
export const uploadUrl = f => `/uploads/${f.id}.${EXT[f.type] || 'bin'}`;

export function createMedia(db) {
  async function removeUpload(id) { await db.deleteFile(id); }
  return {
    removeUpload,
    async startUpload(name, type, size) {
      if (typeof type !== 'string' || ![...IMAGE_TYPES, ...VIDEO_TYPES].includes(type)) return {error: 'Use a JPG, PNG, WebP, GIF or AVIF photo, or an MP4 or WebM video.'};
      const video = VIDEO_TYPES.includes(type);
      const max = (video ? MAX_VIDEO_MB : MAX_IMAGE_MB) * 1048576;
      if (typeof size !== 'number' || !Number.isInteger(size) || size <= 0) return {error: 'Empty file.'};
      if (size > max) return {error: `File is too large. Maximum ${max / 1048576} MB for ${video ? 'videos' : 'photos'}.`};
      const id = crypto.randomBytes(12).toString('hex');
      const chunks = Math.ceil(size / CHUNK_BYTES);
      await db.createFile({id, name: String(name || 'file').slice(0, 200), type, size, chunks});
      return {id, chunks, chunkBytes: CHUNK_BYTES};
    },
    async putChunk(id, idx, bytes) {
      const f = await db.getFile(id);
      if (!f || f.complete) return 'Unknown upload.';
      if (!Number.isInteger(idx) || idx < 0 || idx >= f.chunks) return 'Bad piece number.';
      const expected = idx === f.chunks - 1 ? f.size - idx * CHUNK_BYTES : CHUNK_BYTES;
      if (bytes.length !== expected) return 'Upload piece has the wrong size. Please try again.';
      await db.putChunk(id, idx, bytes);
      return null;
    },
    async finishUpload(id) {
      const f = await db.getFile(id);
      if (!f) return {error: 'Unknown upload.'};
      if ((await db.countChunks(id)) !== f.chunks) return {error: 'Upload is incomplete. Please try again.'};
      await db.completeFile(id);
      return {url: uploadUrl(f), type: f.type, name: f.name, size: f.size};
    },
    async listUploads() {
      return (await db.listFiles()).map(f => ({url: uploadUrl(f), name: f.name, type: f.type, size: f.size, createdAt: f.createdAt}));
    },
    /** Deletes unfinished uploads after 1 day and uploads no content uses after 2 days. */
    async cleanUnusedUploads(contentJson) {
      for (const f of await db.listFilesOlderThan(new Date(Date.now() - 86400000))) {
        const old = Date.now() - new Date(f.createdAt.replace(' ', 'T') + 'Z').getTime() > 2 * 86400000;
        if (!f.complete || (old && !contentJson.includes('/uploads/' + f.id))) await removeUpload(f.id);
      }
    },
    async serve(req, res) {
      const id = String(req.params.file || '').split('.')[0];
      if (!/^[a-f0-9]{24}$/.test(id)) return res.status(404).send('Not found');
      const f = await db.getFile(id);
      if (!f || !f.complete) return res.status(404).send('Not found');
      res.set({'Content-Type': f.type, 'Accept-Ranges': 'bytes', 'Cache-Control': 'public, max-age=31536000, immutable', 'ETag': `"${f.id}"`, 'X-Content-Type-Options': 'nosniff'});
      if (req.headers['if-none-match'] === `"${f.id}"`) return res.status(304).end();
      let start = 0, end = f.size - 1;
      const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
      if (range) {
        if (range[1] === '') start = Math.max(0, f.size - Number(range[2]));
        else { start = Number(range[1]); if (range[2] !== '') end = Math.min(end, Number(range[2])); }
        if (start > end || start >= f.size) return res.status(416).set('Content-Range', `bytes */${f.size}`).end();
        res.status(206).set('Content-Range', `bytes ${start}-${end}/${f.size}`);
      }
      res.set('Content-Length', String(end - start + 1));
      if (req.method === 'HEAD') return res.end();
      const first = Math.floor(start / CHUNK_BYTES), last = Math.floor(end / CHUNK_BYTES);
      async function* pieces() {
        for (let idx = first; idx <= last; idx++) {
          const bytes = await db.getChunk(id, idx);
          if (!bytes) throw new Error('missing piece ' + idx);
          const base = idx * CHUNK_BYTES;
          yield bytes.subarray(Math.max(0, start - base), Math.min(bytes.length, end - base + 1));
        }
      }
      Readable.from(pieces()).on('error', () => res.destroy()).pipe(res);
    },
  };
}
