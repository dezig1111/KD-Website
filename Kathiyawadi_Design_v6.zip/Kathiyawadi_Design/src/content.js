// Site content = the defaults in content-defaults.js, overridden by whatever the
// admin has saved in the database (Services, Projects, Journal, FAQs, Reviews,
// Settings and replaced Photos & Reels).
import {contentDefaults, contentKeys} from './content-defaults.js';

export async function loadContent(db) {
  const data = structuredClone(contentDefaults);
  const saved = {};
  try {
    for (const r of await db.listContent()) {
      if (!contentKeys.includes(r.key)) continue;
      try { data[r.key] = JSON.parse(r.value); saved[r.key] = {updatedAt: r.updatedAt, updatedBy: r.updatedBy}; } catch { /* ignore broken row */ }
    }
  } catch (e) { console.error('Could not load content, using defaults:', e.message); }
  return {data, saved};
}

// Safe to put inside a <script> tag.
export const scriptJson = v => JSON.stringify(v).replace(/</g, '\\u003c').replace(/[\u2028]/g, '\\u2028').replace(/[\u2029]/g, '\\u2029');
