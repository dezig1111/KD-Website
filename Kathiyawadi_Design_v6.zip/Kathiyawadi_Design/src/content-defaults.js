// Default site content. The admin dashboard saves edited copies in D1 (table `content`).
export const contentDefaults = {
    "services": [
        {
            "id": "ui-ux-design",
            "name": "UI/UX Design",
            "short": "UI/UX",
            "icon": "⌘",
            "desc": "Digital experiences that feel as good as they look.",
            "items": [
                "User research & strategy",
                "Web & app design",
                "Design systems",
                "Interactive prototypes"
            ]
        },
        {
            "id": "graphic-design",
            "name": "Graphic Design",
            "short": "Graphic",
            "icon": "✳",
            "desc": "Brands with a voice. Visuals with a point of view.",
            "items": [
                "Logo & brand identity",
                "Social media creatives",
                "Packaging & print",
                "Campaign design"
            ]
        },
        {
            "id": "video-editing",
            "name": "Video Editing",
            "short": "Video",
            "icon": "▶",
            "desc": "Stories worth watching. Until the very last frame.",
            "items": [
                "Reels & short films",
                "YouTube & podcasts",
                "Motion graphics",
                "CGI Video"
            ]
        }
    ],
    "projects": [
        {
            "slug": "savor",
            "title": "Savor. A fresh perspective.",
            "category": "Graphic",
            "industry": "Food",
            "color": "#dce9ba",
            "wordmark": "SAVOR",
            "tagline": "Good food. Better company."
        },
        {
            "slug": "finova",
            "title": "Finance, without the friction.",
            "category": "UI/UX",
            "industry": "Startup",
            "color": "#c9bcf5",
            "wordmark": "finova.",
            "tagline": "Your money. In your corner."
        },
        {
            "slug": "orivelle",
            "title": "Everyday, elevated.",
            "category": "Graphic",
            "industry": "Retail",
            "color": "#e5d8bd",
            "wordmark": "ORIVELLE",
            "tagline": "The art of everyday rituals"
        },
        {
            "slug": "pulse",
            "title": "Care that connects.",
            "category": "UI/UX",
            "industry": "Healthcare",
            "color": "#b8dbde",
            "wordmark": "pulse +",
            "tagline": "A little closer to better care"
        },
        {
            "slug": "urbanest",
            "title": "Spaces. Stories. Possibilities.",
            "category": "Video",
            "industry": "Real Estate",
            "color": "#f3b49d",
            "wordmark": "URBANEST",
            "tagline": "Find your kind of space"
        },
        {
            "slug": "brightpath",
            "title": "A brighter way to learn.",
            "category": "UI/UX",
            "industry": "Education",
            "color": "#f7d865",
            "wordmark": "brightpath",
            "tagline": "Big ideas start small."
        },
        {
            "slug": "chai-chowk",
            "title": "Brewed for conversation.",
            "category": "Graphic",
            "industry": "Food",
            "color": "#e6a265",
            "wordmark": "CHAI CHOWK",
            "tagline": "One more cup?"
        },
        {
            "slug": "makers",
            "title": "Made to move you.",
            "category": "Video",
            "industry": "Other",
            "color": "#b8c8ef",
            "wordmark": "MAKERS",
            "tagline": "From the first spark."
        }
    ],
    "posts": [
        {
            "slug": "logo-grid",
            "title": "Why your logo needs a grid",
            "category": "Graphic",
            "body": "A grid creates consistency. Start with simple geometry, test the mark at small sizes, and let optical balance guide the final adjustments."
        },
        {
            "slug": "ui-mistakes",
            "title": "5 UI mistakes growing startups make",
            "category": "UI/UX",
            "body": "Too many calls to action, weak contrast, unclear labels, inconsistent spacing and missing error states can slow people down. Test one task at a time with real users."
        },
        {
            "slug": "reel-editing",
            "title": "A better rhythm for your next reel",
            "category": "Video",
            "body": "Open with a clear hook. Trim pauses, use captions, and let the soundtrack support the story. Review the final edit without sound before publishing."
        }
    ],
    "faqs": [
        {
            "category": "General",
            "question": "What services do you offer?",
            "answer": "UI/UX design, graphic design and video editing. We can combine services in one project."
        },
        {
            "category": "Pricing",
            "question": "How much does a project cost?",
            "answer": "The pricing page gives illustrative starting points. Your final quote depends on scope, complexity and delivery dates."
        },
        {
            "category": "General",
            "question": "How long does a project take?",
            "answer": "A focused creative can take a few days. A full brand or digital product typically needs several weeks. We agree on milestones before starting."
        },
        {
            "category": "Pricing",
            "question": "How many revisions do I get?",
            "answer": "Revision rounds are agreed in your proposal. Additional scope is quoted before work begins."
        },
        {
            "category": "General",
            "question": "Do you work outside Gujarat?",
            "answer": "Yes. We collaborate remotely with businesses across India and beyond."
        },
        {
            "category": "Graphic",
            "question": "Do you provide source files?",
            "answer": "Final source files and usage rights are specified in your project agreement."
        },
        {
            "category": "Pricing",
            "question": "How do payments work?",
            "answer": "Projects use an agreed advance and milestone payments. The exact schedule appears in your quote."
        },
        {
            "category": "Video",
            "question": "Can you edit videos shot on a phone?",
            "answer": "Yes. Send a sample so we can check resolution, lighting and audio."
        },
        {
            "category": "Video",
            "question": "Do you offer Gujarati and Hindi subtitles?",
            "answer": "Yes, subtitle language and review are included in the scope discussion."
        },
        {
            "category": "UI/UX",
            "question": "Do you also build the website?",
            "answer": "Development can be scoped separately from the design deliverables."
        }
    ],
    "reviews": [],
    "settings": {
        "announcement": "",
        "announcementLink": "",
        "showPricing": false
    },
    "media": {},
    "products": [],
    "pageEdits": {},
    "blocks": []
};
export const contentKeys = Object.keys(contentDefaults);
