// Blocks form posts sent from other websites.
export function sameOrigin(req) {
  try { return new URL(req.headers.origin).host === req.get('host'); } catch { return false; }
}
