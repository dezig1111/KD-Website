// Admin password, login sessions and wrong-password lockout.
// A login lives only inside the open admin page: the page keeps a signed token in memory
// and sends it with every request. Nothing is stored in the browser, so opening /admin,
// refreshing it or opening a new tab always asks for the password again.
import crypto from 'node:crypto';
import {promisify} from 'node:util';
import {ADMIN_PASSWORD, SESSION_HOURS, MAX_ATTEMPTS, LOCK_MINUTES} from '../admin-config.js';

const pbkdf2 = promisify(crypto.pbkdf2);
const TICKET_MINUTES = 5;
const ITERATIONS = 210000;

function sameText(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
const derive = async (password, salt, iterations) => (await pbkdf2(password, salt, iterations, 32, 'sha256')).toString('base64');
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  return `pbkdf2$${ITERATIONS}$${salt.toString('base64')}$${await derive(password, salt, ITERATIONS)}`;
}
async function matches(password, stored) {
  if (!stored) return false;
  const [, iter, salt, hash] = stored.split('$');
  return sameText(await derive(String(password), Buffer.from(salt, 'base64'), Number(iter)), hash);
}

// The admin password can be changed in two places. Whichever was changed last is used:
//  - admin-config.js (ADMIN_PASSWORD): applied when the server starts or someone logs in.
//  - Admin panel > Settings > Change admin password.
export function createAuth(db, {codePassword = ADMIN_PASSWORD} = {}) {
  async function sessionSecret() {
    let s = await db.getMeta('session_secret');
    if (!s) {
      await db.addMetaIfMissing('session_secret', crypto.randomBytes(32).toString('base64'));
      s = await db.getMeta('session_secret');
    }
    return Buffer.from(s, 'base64');
  }
  const sign = async message => crypto.createHmac('sha256', await sessionSecret()).update(message).digest('base64url');

  const lockKey = req => 'fail:' + (req.ip || 'local');

  return {
    /**
     * If ADMIN_PASSWORD in admin-config.js is new (first start, or edited since last time),
     * it becomes the admin password and every device is logged out.
     * Returns true when the code password was applied.
     */
    async syncCodePassword() {
      if (await matches(codePassword, await db.getMeta('code_password'))) return false;
      const hash = await hashPassword(codePassword);
      await db.setMeta('password_hash', hash);
      await db.setMeta('code_password', hash);
      await db.setMeta('password_source', 'code');
      await db.setMeta('session_secret', crypto.randomBytes(32).toString('base64'));
      return true;
    },
    /** "code" = the password in admin-config.js works; "admin" = it was changed in the admin panel. */
    async passwordSource() { return (await db.getMeta('password_source')) || 'code'; },
    async checkPassword(password) {
      await this.syncCodePassword();
      return {ok: await matches(password, await db.getMeta('password_hash')), mustChange: false};
    },
    /** Password changed in the admin panel. Signs out every other device. */
    async setPassword(password) {
      await db.setMeta('password_hash', await hashPassword(password));
      await db.setMeta('password_source', 'admin');
      await db.setMeta('session_secret', crypto.randomBytes(32).toString('base64'));
    },
    passwordProblem(password) {
      if (typeof password !== 'string' || password.length < 8) return 'Use at least 8 characters.';
      if (password.length > 200) return 'That password is too long.';
      return null;
    },

    /** A new login token, valid for SESSION_HOURS while the admin page stays open. */
    async createToken() {
      const payload = `${Date.now() + SESSION_HOURS * 3600 * 1000}.0`;
      return `${payload}.${await sign(payload)}`;
    },

    /** The logged-in admin, or null. Reads the token from the "Authorization: Bearer …" header. */
    async getAdmin(req) {
      const value = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '')?.[1];
      if (!value) return null;
      const [exp, flag, sig] = value.split('.');
      if (!exp || !sig || Number(exp) < Date.now()) return null;
      try { if (!sameText(await sign(`${exp}.${flag}`), sig)) return null; } catch { return null; }
      return {mustChange: false};
    },

    /** One-time ticket so the admin panel can open a website page in "Edit this page" mode. */
    async createEditTicket() {
      const id = crypto.randomBytes(12).toString('hex');
      await db.setMeta('ticket:' + id, String(Date.now() + TICKET_MINUTES * 60000));
      return id;
    },
    /** Uses up a ticket. Returns a login token for that page, or null (used, expired or unknown). */
    async useEditTicket(id) {
      if (!/^[a-f0-9]{24}$/.test(String(id || ''))) return null;
      const exp = await db.getMeta('ticket:' + id);
      if (!exp) return null;
      await db.deleteMeta('ticket:' + id);
      return Number(exp) > Date.now() ? this.createToken() : null;
    },

    async lockedForSeconds(req) {
      const raw = await db.getMeta(lockKey(req));
      if (!raw) return 0;
      try { const {until} = JSON.parse(raw); return until > Date.now() ? Math.ceil((until - Date.now()) / 1000) : 0; } catch { return 0; }
    },
    async recordFailure(req) {
      let n = 0;
      try { const v = JSON.parse((await db.getMeta(lockKey(req))) || '{}'); n = v.until && v.until < Date.now() ? 0 : (v.n || 0); } catch { /* start again */ }
      n++;
      await db.setMeta(lockKey(req), JSON.stringify({n, until: n >= MAX_ATTEMPTS ? Date.now() + LOCK_MINUTES * 60000 : 0}));
      return Math.max(0, MAX_ATTEMPTS - n);
    },
    async clearFailures(req) { await db.deleteMeta(lockKey(req)); },
  };
}
