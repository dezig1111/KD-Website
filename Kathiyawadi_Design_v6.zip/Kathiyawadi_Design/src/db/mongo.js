// MongoDB storage. Collections and indexes are created automatically on start-up.
import {MongoClient, Binary} from 'mongodb';
import {sqlTime} from './time.js';

export function createMongo(uri, dbName) {
  const client = new MongoClient(uri);
  let db;
  const c = name => db.collection(name);
  const hide = {projection: {_id: 0}};
  // Numeric ids (1, 2, 3…) so enquiry numbers look the same as with PostgreSQL.
  const nextId = async name => (await c('counters').findOneAndUpdate({_id: name}, {$inc: {seq: 1}}, {upsert: true, returnDocument: 'after'})).seq;
  const sub = r => ({id: r.id, kind: r.kind, email: r.email, payload: r.payload, status: r.status, note: r.note, createdAt: sqlTime(r.createdAt), updatedAt: r.updatedAt ? sqlTime(r.updatedAt) : null});
  const file = r => r && ({id: r.id, name: r.name, type: r.type, size: r.size, chunks: r.chunks, complete: r.complete, createdAt: sqlTime(r.createdAt)});

  return {
    name: 'MongoDB',
    async init() {
      await client.connect();
      db = client.db(dbName);
      await c('submissions').createIndex({id: 1}, {unique: true});
      await c('bookings').createIndex({slot: 1}, {unique: true});
      await c('bookings').createIndex({id: 1}, {unique: true});
      await c('content').createIndex({key: 1}, {unique: true});
      await c('admin_log').createIndex({id: 1}, {unique: true});
      await c('admin_meta').createIndex({key: 1}, {unique: true});
      await c('media_files').createIndex({id: 1}, {unique: true});
      await c('media_chunks').createIndex({fileId: 1, idx: 1}, {unique: true});
    },
    async close() { await client.close(); },

    // Submissions and bookings
    async insertSubmission({kind, email, payload}) {
      const id = await nextId('submissions');
      await c('submissions').insertOne({id, kind, email, payload, status: 'new', note: '', createdAt: new Date(), updatedAt: null});
      return id;
    },
    // The unique index on slot stops double bookings. If saving the enquiry fails,
    // the booking is removed again so the slot is not left blocked.
    async insertBookingWithSubmission(booking, submission) {
      const id = await nextId('bookings');
      try { await c('bookings').insertOne({id, slot: booking.slot, email: booking.email}); }
      catch (e) { if (e.code === 11000) throw Object.assign(new Error('slot taken'), {code: 'SLOT_TAKEN'}); throw e; }
      try { await this.insertSubmission(submission); }
      catch (e) { await c('bookings').deleteOne({id}); throw e; }
    },
    async listSubmissions(limit = 5000) { return (await c('submissions').find({}, hide).sort({id: -1}).limit(limit).toArray()).map(sub); },
    async getSubmission(id) { const r = await c('submissions').findOne({id}, hide); return r ? sub(r) : null; },
    async updateSubmission(id, patch) {
      const set = {updatedAt: new Date()};
      if (patch.status !== undefined) set.status = patch.status;
      if (patch.note !== undefined) set.note = patch.note;
      await c('submissions').updateOne({id}, {$set: set});
    },
    async deleteSubmission(id) { await c('submissions').deleteOne({id}); },
    async listBookings() { return c('bookings').find({}, hide).sort({slot: -1}).limit(2000).toArray(); },
    async deleteBooking(id) { await c('bookings').deleteOne({id}); },
    async deleteBookingBySlot(slot, email) { await c('bookings').deleteOne({slot, email}); },

    // Editable site content
    async listContent() { return (await c('content').find({}, hide).toArray()).map(r => ({key: r.key, value: r.value, updatedAt: sqlTime(r.updatedAt), updatedBy: r.updatedBy})); },
    async upsertContent(key, value, by) { await c('content').updateOne({key}, {$set: {key, value, updatedAt: new Date(), updatedBy: by}}, {upsert: true}); },
    async deleteContent(key) { await c('content').deleteOne({key}); },

    // Activity log
    async addLog(action, detail) { await c('admin_log').insertOne({id: await nextId('admin_log'), email: 'admin', action, detail, createdAt: new Date()}); },
    async listLog(limit = 100) { return (await c('admin_log').find({}, hide).sort({id: -1}).limit(limit).toArray()).map(r => ({...r, createdAt: sqlTime(r.createdAt)})); },

    // Admin password, session secret, lockouts
    async getMeta(key) { return (await c('admin_meta').findOne({key}))?.value ?? null; },
    async setMeta(key, value) { await c('admin_meta').updateOne({key}, {$set: {key, value, updatedAt: new Date()}}, {upsert: true}); },
    async addMetaIfMissing(key, value) {
      try { await c('admin_meta').updateOne({key}, {$setOnInsert: {key, value, updatedAt: new Date()}}, {upsert: true}); }
      catch (e) { if (e.code !== 11000) throw e; }
    },
    async deleteMeta(key) { await c('admin_meta').deleteOne({key}); },

    // Uploaded photos and videos
    async createFile(f) { await c('media_files').insertOne({...f, complete: false, createdAt: new Date()}); },
    async getFile(id) { return file(await c('media_files').findOne({id}, hide)); },
    async completeFile(id) { await c('media_files').updateOne({id}, {$set: {complete: true}}); },
    async listFiles() { return (await c('media_files').find({complete: true}, hide).sort({createdAt: -1}).toArray()).map(file); },
    async listFilesOlderThan(date) { return (await c('media_files').find({createdAt: {$lt: date}}, hide).toArray()).map(file); },
    async deleteFile(id) { await c('media_chunks').deleteMany({fileId: id}); await c('media_files').deleteOne({id}); },
    async putChunk(fileId, idx, data) { await c('media_chunks').updateOne({fileId, idx}, {$set: {fileId, idx, data: new Binary(data)}}, {upsert: true}); },
    async getChunk(fileId, idx) { const r = await c('media_chunks').findOne({fileId, idx}); return r ? Buffer.from(r.data.buffer) : null; },
    async countChunks(fileId) { return c('media_chunks').countDocuments({fileId}); },
  };
}
