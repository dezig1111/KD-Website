// PostgreSQL storage. Tables are created automatically on start-up.
import pg from 'pg';
import {sqlTime} from './time.js';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS submissions (
  id         SERIAL PRIMARY KEY,
  kind       TEXT NOT NULL,
  email      TEXT NOT NULL,
  payload    JSONB NOT NULL,
  status     TEXT NOT NULL DEFAULT 'new',
  note       TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS submissions_kind_idx ON submissions (kind);
CREATE TABLE IF NOT EXISTS bookings (
  id    SERIAL PRIMARY KEY,
  slot  TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS content (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by TEXT
);
CREATE TABLE IF NOT EXISTS admin_log (
  id         SERIAL PRIMARY KEY,
  email      TEXT NOT NULL DEFAULT 'admin',
  action     TEXT NOT NULL,
  detail     TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS admin_meta (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS media_files (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  type       TEXT NOT NULL,
  size       BIGINT NOT NULL,
  chunks     INTEGER NOT NULL,
  complete   BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS media_chunks (
  file_id TEXT NOT NULL REFERENCES media_files(id) ON DELETE CASCADE,
  idx     INTEGER NOT NULL,
  data    BYTEA NOT NULL,
  PRIMARY KEY (file_id, idx)
);`;

export function createPostgres(url) {
  const pool = new pg.Pool({connectionString: url, max: 10});
  const q = (text, params) => pool.query(text, params);
  const sub = r => ({id: r.id, kind: r.kind, email: r.email, payload: r.payload, status: r.status, note: r.note, createdAt: sqlTime(r.created_at), updatedAt: r.updated_at ? sqlTime(r.updated_at) : null});
  const file = r => r && ({id: r.id, name: r.name, type: r.type, size: Number(r.size), chunks: r.chunks, complete: r.complete, createdAt: sqlTime(r.created_at)});

  return {
    name: 'PostgreSQL',
    async init() { await q(SCHEMA); },
    /** Tests only: removes every table and creates them again empty. */
    async wipe() { await q('DROP TABLE IF EXISTS media_chunks, media_files, admin_meta, admin_log, content, bookings, submissions CASCADE'); await q(SCHEMA); },
    async close() { await pool.end(); },

    // Submissions and bookings
    async insertSubmission({kind, email, payload}) {
      const r = await q('INSERT INTO submissions (kind, email, payload) VALUES ($1, $2, $3) RETURNING id', [kind, email, payload]);
      return r.rows[0].id;
    },
    async insertBookingWithSubmission(booking, submission) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        await client.query('INSERT INTO bookings (slot, email) VALUES ($1, $2)', [booking.slot, booking.email]);
        await client.query('INSERT INTO submissions (kind, email, payload) VALUES ($1, $2, $3)', [submission.kind, submission.email, submission.payload]);
        await client.query('COMMIT');
      } catch (e) {
        await client.query('ROLLBACK');
        if (e.code === '23505') throw Object.assign(new Error('slot taken'), {code: 'SLOT_TAKEN'});
        throw e;
      } finally { client.release(); }
    },
    async listSubmissions(limit = 5000) { return (await q('SELECT * FROM submissions ORDER BY id DESC LIMIT $1', [limit])).rows.map(sub); },
    async getSubmission(id) { const r = (await q('SELECT * FROM submissions WHERE id = $1', [id])).rows[0]; return r ? sub(r) : null; },
    async updateSubmission(id, patch) {
      await q('UPDATE submissions SET status = COALESCE($2, status), note = COALESCE($3, note), updated_at = now() WHERE id = $1', [id, patch.status ?? null, patch.note ?? null]);
    },
    async deleteSubmission(id) { await q('DELETE FROM submissions WHERE id = $1', [id]); },
    async listBookings() { return (await q('SELECT id, slot, email FROM bookings ORDER BY slot DESC LIMIT 2000')).rows; },
    async deleteBooking(id) { await q('DELETE FROM bookings WHERE id = $1', [id]); },
    async deleteBookingBySlot(slot, email) { await q('DELETE FROM bookings WHERE slot = $1 AND email = $2', [slot, email]); },

    // Editable site content
    async listContent() { return (await q('SELECT * FROM content')).rows.map(r => ({key: r.key, value: r.value, updatedAt: sqlTime(r.updated_at), updatedBy: r.updated_by})); },
    async upsertContent(key, value, by) {
      await q('INSERT INTO content (key, value, updated_at, updated_by) VALUES ($1, $2, now(), $3) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now(), updated_by = EXCLUDED.updated_by', [key, value, by]);
    },
    async deleteContent(key) { await q('DELETE FROM content WHERE key = $1', [key]); },

    // Activity log
    async addLog(action, detail) { await q('INSERT INTO admin_log (action, detail) VALUES ($1, $2)', [action, detail]); },
    async listLog(limit = 100) { return (await q('SELECT * FROM admin_log ORDER BY id DESC LIMIT $1', [limit])).rows.map(r => ({id: r.id, email: r.email, action: r.action, detail: r.detail, createdAt: sqlTime(r.created_at)})); },

    // Admin password, session secret, lockouts
    async getMeta(key) { return (await q('SELECT value FROM admin_meta WHERE key = $1', [key])).rows[0]?.value ?? null; },
    async setMeta(key, value) { await q('INSERT INTO admin_meta (key, value, updated_at) VALUES ($1, $2, now()) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()', [key, value]); },
    async addMetaIfMissing(key, value) { await q('INSERT INTO admin_meta (key, value) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING', [key, value]); },
    async deleteMeta(key) { await q('DELETE FROM admin_meta WHERE key = $1', [key]); },

    // Uploaded photos and videos
    async createFile(f) { await q('INSERT INTO media_files (id, name, type, size, chunks) VALUES ($1, $2, $3, $4, $5)', [f.id, f.name, f.type, f.size, f.chunks]); },
    async getFile(id) { return file((await q('SELECT * FROM media_files WHERE id = $1', [id])).rows[0]); },
    async completeFile(id) { await q('UPDATE media_files SET complete = true WHERE id = $1', [id]); },
    async listFiles() { return (await q('SELECT * FROM media_files WHERE complete ORDER BY created_at DESC')).rows.map(file); },
    async listFilesOlderThan(date) { return (await q('SELECT * FROM media_files WHERE created_at < $1', [date])).rows.map(file); },
    async deleteFile(id) { await q('DELETE FROM media_files WHERE id = $1', [id]); },
    async putChunk(fileId, idx, data) {
      await q('INSERT INTO media_chunks (file_id, idx, data) VALUES ($1, $2, $3) ON CONFLICT (file_id, idx) DO UPDATE SET data = EXCLUDED.data', [fileId, idx, data]);
    },
    async getChunk(fileId, idx) { return (await q('SELECT data FROM media_chunks WHERE file_id = $1 AND idx = $2', [fileId, idx])).rows[0]?.data ?? null; },
    async countChunks(fileId) { return Number((await q('SELECT COUNT(*) AS n FROM media_chunks WHERE file_id = $1', [fileId])).rows[0].n); },
  };
}
