// Built-in PostgreSQL (DB_TYPE=builtin): a real PostgreSQL server that comes with
// `npm install` and keeps its data in the project's data/postgres folder.
// Nothing to install or configure — handy for running the site on your own computer.
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import pg from 'pg';
import {createPostgres} from './postgres.js';

const USER = 'postgres';
const PASSWORD = 'kathiyawadi-local';

const portOpen = port => new Promise(resolve => {
  const s = net.connect(port, '127.0.0.1');
  s.once('connect', () => { s.destroy(); resolve(true); });
  s.once('error', () => resolve(false));
});

export function createBuiltinPostgres({dataDir, port, database}) {
  let server = null;      // set when this process started the database server
  let inner = null;       // the normal PostgreSQL adapter, created once the server runs
  let lastError = '';     // last message from PostgreSQL, shown if it fails to start
  const url = `postgres://${USER}:${encodeURIComponent(PASSWORD)}@127.0.0.1:${port}/${database}`;

  async function startServer() {
    const {default: EmbeddedPostgres} = await import('embedded-postgres').catch(() => {
      throw new Error('The built-in database is not installed. Run "npm install" again (it needs an internet connection the first time).');
    });
    // A server from an earlier run that is still running (for example after an auto-restart) is reused.
    if (await portOpen(port)) return;
    fs.mkdirSync(path.dirname(dataDir), {recursive: true});
    const isNew = !fs.existsSync(path.join(dataDir, 'PG_VERSION'));
    server = new EmbeddedPostgres({
      databaseDir: dataDir, user: USER, password: PASSWORD, port, persistent: true,
      // PostgreSQL refuses to run as root (some Linux servers); this lets it run as its own user.
      createPostgresUser: typeof process.getuid === 'function' && process.getuid() === 0,
      onLog: m => { if (/FATAL|ERROR|PANIC/.test(String(m))) lastError = String(m).trim(); },
      onError: m => { if (String(m).trim()) lastError = String(m).trim(); },
    });
    if (isNew) {
      console.log('  Setting up the built-in database for the first time (takes a few seconds)…');
      try { await server.initialise(); }
      catch (e) { throw new Error((e && e.message) || lastError || 'Could not set up the built-in database.'); }
    }
    // A crash can leave a stale lock file behind; PostgreSQL would refuse to start.
    const pid = path.join(dataDir, 'postmaster.pid');
    if (fs.existsSync(pid)) fs.rmSync(pid);
    // PostgreSQL only starts when its data folder is private (copying a project can loosen this).
    if (process.platform !== 'win32') fs.chmodSync(dataDir, 0o700);
    try { await server.start(); }
    catch (e) { throw new Error((e && e.message) || lastError.split('\n').find(l => /FATAL|ERROR/.test(l)) || lastError || 'The built-in database did not start.'); }
  }

  async function ensureDatabase() {
    const admin = new pg.Client({connectionString: url.replace(/\/[^/]+$/, '/postgres')});
    await admin.connect();
    try {
      const r = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [database]);
      if (!r.rowCount) await admin.query(`CREATE DATABASE "${database.replace(/"/g, '')}"`);
    } finally { await admin.end(); }
  }

  const api = {
    name: 'PostgreSQL (built-in)',
    async init() {
      await startServer();
      await ensureDatabase();
      inner = createPostgres(url);
      Object.assign(api, Object.fromEntries(Object.entries(inner).filter(([k]) => !['name', 'init', 'close'].includes(k))));
      await inner.init();
    },
    async close() {
      if (inner) await inner.close().catch(() => {});
      if (server) await server.stop().catch(() => {});
    },
  };
  return api;
}
