// Dates are sent to the admin panel as "YYYY-MM-DD HH:MM:SS" in UTC.
export const sqlTime = d => (d ? new Date(d).toISOString().slice(0, 19).replace('T', ' ') : null);
