// Picks the database from .env:
//   DB_TYPE=builtin   → PostgreSQL that comes with the project (no setup, default)
//   DB_TYPE=postgres  → your own PostgreSQL server (DATABASE_URL)
//   DB_TYPE=mongodb   → your own MongoDB server or MongoDB Atlas (MONGODB_URI)
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createPostgres} from './postgres.js';
import {createMongo} from './mongo.js';
import {createBuiltinPostgres} from './builtin.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

export function createDatabase(env = process.env) {
  const type = (env.DB_TYPE || 'builtin').toLowerCase().trim();
  if (type === 'builtin' || type === 'built-in' || type === 'local') {
    return createBuiltinPostgres({
      dataDir: path.resolve(root, env.BUILTIN_DB_DIR || 'data/postgres'),
      port: Number(env.BUILTIN_DB_PORT || 5433),
      database: env.BUILTIN_DB_NAME || 'kathiyawadi',
    });
  }
  if (type === 'postgres' || type === 'postgresql') {
    return createPostgres(env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/kathiyawadi');
  }
  if (type === 'mongodb' || type === 'mongo') {
    return createMongo(env.MONGODB_URI || 'mongodb://localhost:27017', env.MONGODB_DB || 'kathiyawadi');
  }
  throw new Error(`Unknown DB_TYPE "${type}". Use builtin, postgres or mongodb in your .env file.`);
}
