// POST /api/submit — saves every form on the website (contact, project, booking,
// career, newsletter) after checking the data.
import express from 'express';
import {sameOrigin} from '../http.js';

const TIMES = new Set(['10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30']);

/** Returns an error message, or null when the data is valid. Also normalises d. */
export function validateSubmission(d) {
  if (!d || typeof d !== 'object' || Array.isArray(d)) return 'Invalid request';
  if (!['contact', 'project', 'newsletter', 'career', 'booking'].includes(d.kind)) return 'Choose a valid request type';
  if (typeof d.email !== 'string' || d.email.length > 254 || !/^\S+@\S+\.\S+$/.test(d.email)) return 'Enter a valid email address';
  d.email = d.email.trim().toLowerCase();
  if (Object.keys(d).length > 40) return 'Too many fields';
  for (const [key, value] of Object.entries(d)) {
    if (!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key)) return 'Invalid field name';
    if (typeof value === 'string' && value.length > 8000) return 'Field too long: ' + key;
    if (value !== null && typeof value === 'object' && !(key === 'service' && Array.isArray(value))) return 'Invalid field: ' + key;
  }
  if (d.kind !== 'newsletter' && (typeof d.name !== 'string' || !d.name.trim() || d.name.length > 150)) return 'Your name is required';
  if (d.kind !== 'newsletter' && ![true, 'yes', 'on'].includes(d.consent)) return 'Please agree to the privacy policy';
  if (d.kind === 'contact' && (typeof d.message !== 'string' || d.message.trim().length < 10)) return 'Please include a project brief of at least 10 characters';
  if (d.kind === 'project' && (!Array.isArray(d.service) || !d.service.length || d.service.some(x => !['UI/UX', 'Graphic', 'Video'].includes(x)) || typeof d.description !== 'string' || d.description.trim().length < 20)) return 'Complete your project brief';
  if (d.kind === 'career' && (typeof d.experience !== 'string' || !d.experience.trim() || typeof d.message !== 'string' || !d.message.trim())) return 'Complete your application';
  if (d.kind === 'contact' && (typeof d.phone !== 'string' || !d.phone.trim())) return 'Phone No. / WhatsApp is required';
  if (d.phone && (typeof d.phone !== 'string' || !/^\+?[\d\s()-]{7,20}$/.test(d.phone))) return 'Enter a valid phone number';
  if (d.kind === 'booking') {
    if (typeof d.slot !== 'string') return 'Choose an available slot';
    const date = new Date(d.slot), delta = date.getTime() - Date.now();
    if (!Number.isFinite(delta) || delta <= 0 || delta > 15 * 86400000) return 'Choose an available future date';
    const local = new Date(date.getTime() + 19800000), time = local.toISOString().slice(11, 16);
    if (local.getUTCDay() === 0 || !TIMES.has(time) || date.getUTCSeconds() !== 0 || date.getUTCMilliseconds() !== 0) return 'Choose an IST business-hour slot';
    d.slot = date.toISOString();
  }
  return null;
}

export function submitRoutes(app, {db}) {
  const fail = (res, error, status = 400) => res.status(status).json({error});
  app.post('/api/submit', express.text({type: () => true, limit: '20kb'}), async (req, res) => {
    if (!sameOrigin(req)) return fail(res, 'Invalid origin', 403);
    if (!req.is('application/json')) return fail(res, 'Send JSON', 415);
    let d;
    try { d = JSON.parse(req.body); } catch { return fail(res, 'Invalid JSON'); }
    const problem = validateSubmission(d);
    if (problem) return fail(res, problem);
    const record = {kind: d.kind, email: d.email, payload: d};
    try {
      if (d.kind === 'booking') await db.insertBookingWithSubmission({slot: d.slot, email: d.email}, record);
      else await db.insertSubmission(record);
      res.json({ok: true});
    } catch (e) {
      if (e.code === 'SLOT_TAKEN') return fail(res, 'That slot is booked. Please choose another.', 409);
      console.error('Saving a form failed:', e);
      fail(res, 'Unable to save. Please try again.', 500);
    }
  });
}
