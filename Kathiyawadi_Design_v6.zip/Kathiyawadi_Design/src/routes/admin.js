// Admin panel: /admin page, login/logout, the admin API and file uploads.
// Everything except the login page needs the admin password.
import path from 'node:path';
import express from 'express';
import {sameOrigin} from '../http.js';
import {contentKeys} from '../content-defaults.js';
import {loadContent} from '../content.js';
import {mediaSlots, mediaSlotPaths, IMAGE_TYPES, VIDEO_TYPES, MAX_IMAGE_MB, MAX_VIDEO_MB, CHUNK_BYTES} from '../media-slots.js';

const STATUSES = ['new', 'contacted', 'in-progress', 'won', 'closed', 'spam'];
const PRIVATE = {'Cache-Control': 'private, no-store', 'X-Robots-Tag': 'noindex, nofollow', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin'};
// The admin page files contain no data; everything they show comes from the API, which needs the password.
const ASSETS = new Set(['admin.css', 'admin.js', 'login.css', 'login.js', 'page-editor.js', 'page-editor.css']);

// Page text/button changes made with "Edit this page".
function checkPageEdits(v) {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return 'Invalid page changes';
  const pages = Object.entries(v);
  if (pages.length > 200) return 'Too many pages';
  for (const [page, list] of pages) {
    if (page !== '*' && !/^\/[A-Za-z0-9/_-]{0,200}$/.test(page)) return 'Invalid page: ' + page;
    if (!Array.isArray(list) || list.length > 400) return 'Invalid changes for ' + page;
    for (const e of list) {
      if (!e || typeof e !== 'object' || typeof e.sel !== 'string' || !e.sel || e.sel.length > 500) return 'Invalid change on ' + page;
      if (e.html !== undefined && (typeof e.html !== 'string' || e.html.length > 5000)) return 'Text too long on ' + page;
      if (e.href !== undefined && (typeof e.href !== 'string' || e.href.length > 500 || !/^(\/|#|https?:\/\/|mailto:|tel:)/i.test(e.href.trim()))) return 'Links must start with /, https://, mailto: or tel:';
      if (e.hide !== undefined && typeof e.hide !== 'boolean') return 'Invalid change on ' + page;
      if (Object.keys(e).some(k => !['sel', 'html', 'href', 'hide'].includes(k))) return 'Invalid change on ' + page;
    }
  }
  return null;
}

export function adminRoutes(app, {db, auth, media, root}) {
  const adminDir = path.join(root, 'admin');
  const json = express.json({limit: '400kb'});
  const needAdmin = async (req, res, next) => {
    const admin = await auth.getAdmin(req);
    if (!admin) return res.status(401).set(PRIVATE).json({error: 'Please log in again.'});
    req.admin = admin;
    next();
  };
  const needSameOrigin = (req, res, next) => (sameOrigin(req) ? next() : res.status(403).json({error: 'Invalid origin'}));
  const log = (action, detail = '') => db.addLog(action, String(detail).slice(0, 500));

  // Pages
  // /admin always starts at the password screen (also after a refresh or in a new tab).
  app.get(['/admin', '/admin/'], (req, res) => res.set(PRIVATE).sendFile(path.join(adminDir, 'admin.html')));
  app.get('/admin-assets/:file', (req, res, next) => {
    if (!ASSETS.has(req.params.file)) return next();
    res.set(PRIVATE).sendFile(path.join(adminDir, req.params.file));
  });

  // Login / logout
  app.post('/api/admin/login', needSameOrigin, json, async (req, res) => {
    res.set('Cache-Control', 'no-store');
    const wait = await auth.lockedForSeconds(req);
    if (wait) return res.status(429).json({error: `Too many wrong tries. Try again in ${Math.ceil(wait / 60)} minute${wait > 60 ? 's' : ''}.`});
    const {ok, mustChange} = await auth.checkPassword(typeof req.body?.password === 'string' ? req.body.password : '');
    if (!ok) {
      const left = await auth.recordFailure(req);
      return res.status(left ? 401 : 429).json({error: left ? `Wrong password. ${left} ${left === 1 ? 'try' : 'tries'} left.` : 'Too many wrong tries. Login is locked for a while.'});
    }
    await auth.clearFailures(req);
    res.json({ok: true, token: await auth.createToken()});
  });
  app.post('/api/admin/logout', needSameOrigin, (req, res) => res.json({ok: true}));

  // Everything the admin panel shows
  app.get('/api/admin', needAdmin, async (req, res) => {
    res.set(PRIVATE);
    if (req.admin.mustChange) return res.json({mustChange: true});
    const [submissions, bookings, logRows, {data, saved}, uploads] = await Promise.all([
      db.listSubmissions(), db.listBookings(), db.listLog(), loadContent(db), media.listUploads(),
    ]);
    res.json({admin: {name: 'Admin'}, mediaSlots, uploads, limits: {IMAGE_TYPES, VIDEO_TYPES, MAX_IMAGE_MB, MAX_VIDEO_MB}, submissions, bookings, log: logRows, content: data, saved, statuses: STATUSES, database: db.name, passwordSource: await auth.passwordSource()});
  });

  // One piece of an upload: POST /api/admin/upload?id=<id>&idx=<n>
  app.post('/api/admin/upload', needSameOrigin, needAdmin, express.raw({type: () => true, limit: CHUNK_BYTES}), async (req, res) => {
    if (req.admin.mustChange) return res.status(403).json({error: 'Please choose a new password first.'});
    const id = String(req.query.id || ''), idx = Number(req.query.idx);
    if (!/^[a-f0-9]{24}$/.test(id)) return res.status(400).json({error: 'Bad upload id'});
    const error = await media.putChunk(id, idx, Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0));
    error ? res.status(400).json({error}) : res.json({ok: true});
  });

  // Admin actions
  app.post('/api/admin', needSameOrigin, needAdmin, json, async (req, res) => {
    res.set(PRIVATE);
    const d = req.body || {};
    const bad = (error, status = 400) => res.status(status).json({error});

    if (d.action === 'changePassword') {
      if (!(await auth.checkPassword(String(d.current || ''))).ok) return bad('Your current password is not correct.');
      const problem = auth.passwordProblem(d.password);
      if (problem) return bad(problem);
      await auth.setPassword(d.password);
      await log('change password');
      // Changing the password logs out every other open admin page; this page gets a fresh login.
      return res.json({ok: true, token: await auth.createToken()});
    }
    if (req.admin.mustChange) return bad('Please choose a new password first.', 403);

    switch (d.action) {
      case 'editTicket': return res.json({ticket: await auth.createEditTicket()});
      case 'updateSubmission': {
        const id = Number(d.id);
        if (!Number.isInteger(id)) return bad('Bad id');
        const patch = {};
        if (d.status !== undefined) { if (!STATUSES.includes(d.status)) return bad('Bad status'); patch.status = d.status; }
        if (d.note !== undefined) { if (typeof d.note !== 'string' || d.note.length > 5000) return bad('Bad note'); patch.note = d.note; }
        await db.updateSubmission(id, patch);
        await log('update enquiry', '#' + id + (patch.status ? ' → ' + patch.status : '') + (patch.note !== undefined ? ' (note)' : ''));
        return res.json({ok: true});
      }
      case 'deleteSubmission': {
        const ids = (Array.isArray(d.ids) ? d.ids : [d.id]).map(Number).filter(Number.isInteger);
        if (!ids.length) return bad('Bad id');
        for (const id of ids) {
          const row = await db.getSubmission(id);
          if (!row) continue;
          if (row.kind === 'booking' && row.payload?.slot) await db.deleteBookingBySlot(row.payload.slot, row.email);
          await db.deleteSubmission(id);
        }
        await log('delete enquiry', ids.map(i => '#' + i).join(', '));
        return res.json({ok: true});
      }
      case 'deleteBooking': {
        const id = Number(d.id);
        if (!Number.isInteger(id)) return bad('Bad id');
        await db.deleteBooking(id);
        await log('free booking slot', '#' + id);
        return res.json({ok: true});
      }
      case 'saveContent': {
        const key = d.key, v = d.value;
        if (!contentKeys.includes(key)) return bad('Unknown section');
        const isObject = key === 'settings' || key === 'media' || key === 'pageEdits';
        if (key === 'pageEdits') { const problem = checkPageEdits(v); if (problem) return bad(problem); }
        if (key === 'media' && v && typeof v === 'object' && Object.entries(v).some(([k, u]) => !mediaSlotPaths.has(k) || typeof u !== 'string' || !/^\/uploads\/[a-f0-9]{24}\.[a-z0-9]+$/.test(u))) return bad('Invalid media');
        if (isObject ? (!v || typeof v !== 'object' || Array.isArray(v)) : !Array.isArray(v)) return bad('Invalid data');
        if (!isObject && v.some(x => !x || typeof x !== 'object' || Array.isArray(x))) return bad('Invalid item');
        const value = JSON.stringify(v);
        if (value.length > 300000) return bad('Too large', 413);
        await db.upsertContent(key, value, 'admin');
        media.cleanUnusedUploads(JSON.stringify(await db.listContent())).catch(e => console.error('Cleanup failed:', e.message));
        await log('save content', key + (isObject ? '' : ' (' + v.length + ' items)'));
        return res.json({ok: true});
      }
      case 'resetContent': {
        if (!contentKeys.includes(d.key)) return bad('Unknown section');
        await db.deleteContent(d.key);
        await log('reset content', d.key);
        return res.json({ok: true});
      }
      case 'uploadStart': {
        const r = await media.startUpload(d.name, d.type, d.size);
        return r.error ? bad(r.error) : res.json(r);
      }
      case 'uploadFinish': {
        const r = await media.finishUpload(String(d.id || ''));
        if (r.error) return bad(r.error);
        await log('upload file', r.name + ' (' + Math.round(r.size / 1024) + ' KB)');
        return res.json(r);
      }
      case 'deleteUpload': {
        const m = /^\/uploads\/([a-f0-9]{24})\./.exec(String(d.url || ''));
        if (!m) return bad('Bad file');
        if (JSON.stringify(await db.listContent()).includes(m[1])) return bad('This file is still used on the website. Restore the original or pick another file first.');
        await media.removeUpload(m[1]);
        await log('delete file', d.url);
        return res.json({ok: true});
      }
    }
    return bad('Unknown action');
  });

  // Uploaded photos and videos (public, so the website can show them)
  app.get('/uploads/:file', (req, res) => media.serve(req, res));
  app.head('/uploads/:file', (req, res) => media.serve(req, res));
}
