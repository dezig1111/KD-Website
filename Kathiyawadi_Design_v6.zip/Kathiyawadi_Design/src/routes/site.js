// Public website pages. Every page uses views/index.html; public/app.js draws the
// page content in the browser. The server adds page titles/SEO tags, the current
// site content from the database and (for the admin only) an "Admin panel" button.
import fs from 'node:fs';
import path from 'node:path';
import {loadContent, scriptJson} from '../content.js';

const ROUTES = new Set(['/', '/about', '/services', '/work', '/products', '/process', '/pricing', '/team', '/team/viraj', '/team/ketu', '/team/collaborators', '/testimonials', '/blog', '/book-a-call', '/careers', '/faq', '/contact', '/privacy', '/terms', '/thank-you',
  ...['savor', 'finova', 'orivelle', 'pulse', 'urbanest', 'brightpath', 'chai-chowk', 'makers'].map(s => '/work/' + s),
  ...['logo-grid', 'ui-mistakes', 'reel-editing'].map(s => '/blog/' + s)]);

export function siteRoutes(app, {db, auth, root}) {
  const shellFile = path.join(root, 'views', 'index.html');
  let cached = null;
  // In development the file is re-read on every request so edits show immediately.
  const shell = () => (process.env.NODE_ENV === 'production' ? (cached ??= fs.readFileSync(shellFile, 'utf8')) : fs.readFileSync(shellFile, 'utf8'));

  // Old links
  app.get('/start-project', (req, res) => res.redirect(308, '/contact' + (req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '')));
  app.get('/services/:service', (req, res) => res.redirect(308, '/services#service-' + req.params.service));

  app.get('/{*page}', async (req, res, next) => {
    if (!req.accepts('html')) return next();
    const pagePath = decodeURIComponent(req.path).replace(/\/$/, '') || '/';
    const {data} = await loadContent(db);
    const slugs = (key, prefix) => (data[key] || []).map(x => prefix + x?.slug);
    const hidden = Array.isArray(data.settings?.hiddenPages) ? data.settings.hiddenPages : (data.settings?.showPricing ? [] : ['/pricing']);
    const isHidden = pagePath !== '/' && hidden.some(h => typeof h === 'string' && h !== '/' && (pagePath === h || pagePath.startsWith(h + '/')));
    const known = !isHidden && (ROUTES.has(pagePath) || slugs('projects', '/work/').includes(pagePath) || slugs('posts', '/blog/').includes(pagePath) || (data.products || []).filter(p => p?.published !== false).map(p => '/products/' + p.slug).includes(pagePath));
    // "Edit this page" opened from the admin panel: ?edit=<one-time ticket>. A refresh ends it.
    const editToken = req.query.edit ? await auth.useEditTicket(req.query.edit) : null;

    const label = pagePath === '/' ? 'Creative Studio' : pagePath.split('/').pop().replaceAll('-', ' ');
    const esc = s => s.replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
    const title = esc(label + ' | Kathiyawadi Design');
    const description = esc('Explore ' + label + ' at Kathiyawadi Design, a creative studio for UI/UX, graphic design and video editing in Gujarat.');
    const origin = process.env.SITE_URL || `${req.protocol}://${req.get('host')}`;
    const url = esc(origin + pagePath);
    const head = `<meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta property="og:type" content="website"><meta property="og:url" content="${url}"><link rel="canonical" href="${url}">`
      + `<script type="application/ld+json">${scriptJson({'@context': 'https://schema.org', '@type': 'ProfessionalService', name: 'Kathiyawadi Design', url: origin, telephone: '+919313780425', address: {'@type': 'PostalAddress', addressLocality: 'Ahmedabad', addressRegion: 'Gujarat', addressCountry: 'IN'}})}</script>`
      + `<script>window.__KD__=${scriptJson(data)}</script><script src="/media-swap.js"></script>`;
    const html = shell()
      .replace(/<title>[^<]*<\/title>/, `<title>${title}</title>`)
      .replace('</head>', head + '</head>')
      .replace('</head>', editToken ? `<link rel="stylesheet" href="/admin-assets/page-editor.css"><script>window.__KD_EDIT__=${scriptJson({token: editToken})}</script></head>` : '</head>')
      .replace('</body>', (editToken ? '<script src="/admin-assets/page-editor.js" defer></script>' : '') + '</body>');
    res.status(known ? 200 : 404).set({'Cache-Control': editToken ? 'no-store' : 'private, no-cache', 'Content-Type': 'text/html; charset=utf-8'}).send(html);
  });
}
