const reel = (file, poster, title) => [
    { path: `/media/${file}`, label: `${title} — video`, group: 'Reels', kind: 'video', usedOn: 'Home reel carousel', pair: `/media/${poster}` },
];
export const mediaSlots = [
    ...reel('coffee-reel.mp4', 'cafe-campaign.webp', 'Savor reel'),
    ...reel('bloom-reel.mp4', 'flower-poster.jpg', 'In Bloom reel'),
    ...reel('space-reel.mp4', 'architecture.jpg', 'Urbanest reel'),
    ...reel('matter-reel.mp4', 'matter-poster.jpg', 'Make It Matter reel'),
    ...reel('color-reel.mp4', 'color-poster.jpg', 'Colour In Motion reel'),
    { path: '/media/cafe-campaign.webp', label: 'Savor campaign photo', group: 'Project & campaign photos', kind: 'image', usedOn: 'Home, Services, Work header, Savor reel cover' },
    { path: '/media/flower-poster.jpg', label: 'In Bloom photo', group: 'Project & campaign photos', kind: 'image', usedOn: 'In Bloom reel cover, project page' },
    { path: '/media/architecture.jpg', label: 'Urbanest architecture photo', group: 'Project & campaign photos', kind: 'image', usedOn: 'Urbanest reel cover, social post, Work header' },
    { path: '/media/matter-poster.jpg', label: 'Make It Matter poster', group: 'Project & campaign photos', kind: 'image', usedOn: 'Make It Matter reel cover, Services' },
    { path: '/media/color-poster.jpg', label: 'Colour In Motion poster', group: 'Project & campaign photos', kind: 'image', usedOn: 'Colour In Motion reel cover' },
    { path: '/media/studio-workspace-sample.jpg', label: 'Studio workspace photo', group: 'About & team', kind: 'image', usedOn: 'About us' },
    { path: '/media/leadership-founder-sample.jpg', label: 'Founder & CEO portrait (Viraj)', group: 'About & team', kind: 'image', usedOn: 'About us' },
    { path: '/media/leadership-coo-sample.jpg', label: 'COO portrait (Ketu Patel)', group: 'About & team', kind: 'image', usedOn: 'About us' },
    { path: '/media/leadership-social-sample.jpg', label: 'Social Media Manager portrait', group: 'About & team', kind: 'image', usedOn: 'About us' },
    ...Array.from({ length: 12 }, (_, i) => ({ path: `/assets/service-icons/service-${i + 1}.webp`, label: `Service icon ${i + 1}`, group: 'Service icons', kind: 'image', usedOn: `Services (${['UI/UX', 'Graphic', 'Video'][Math.floor(i / 4)]} item ${i % 4 + 1})` })),
    { path: '/media/kd-mark.png', label: 'Loader mark (round KD)', group: 'Logo', kind: 'image', usedOn: 'Loading screen' },
    { path: '/media/kathiyawadi-design-official-logo.png', label: 'Logo', group: 'Logo', kind: 'image', usedOn: 'Header and footer' },
];
export const mediaSlotPaths = new Set(mediaSlots.map(s => s.path));
export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];
export const VIDEO_TYPES = ['video/mp4', 'video/webm'];
export const MAX_IMAGE_MB = 15;
export const MAX_VIDEO_MB = 60;
export const CHUNK_BYTES = 768 * 1024;
