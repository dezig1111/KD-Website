# Kathiyawadi Design — website + admin panel

Plain **HTML, CSS and JavaScript** front end, a small **Node.js (Express)** server, and your choice of **PostgreSQL** or **MongoDB** for the database.

## 1. What you need

- **Node.js 20.6 or newer** (the LTS version from https://nodejs.org). That's all.
- You don't need to install a database. By default the site uses a **built-in PostgreSQL** that comes with `npm install` and keeps its data in the `data/` folder.
- Later you can switch to your own **PostgreSQL** or **MongoDB** server (see step 4).

## 2. Run it

**Easiest:** double-click the start file in the project folder:
- Windows: `start-windows.bat`
- Mac: `start-mac.command`. The first time, right-click it → Open.
- Linux: `start-linux.sh`

It installs everything the first time, starts the site and opens http://localhost:3000.

**Or in VS Code:**
1. File → Open Folder… → choose the `Kathiyawadi_Design` folder.
2. Terminal → New Terminal, then run this once:
   ```
   npm install
   ```
3. Start the site:
   ```
   npm run dev
   ```
4. Open **http://localhost:3000**. The admin panel is at **http://localhost:3000/admin**.

The terminal shows the address and the first-time admin password. Keep the terminal open while you use the site, and press Ctrl+C to stop it.

> Don't open `views/index.html` by double-clicking. The site only works through `npm run dev` (or the start file), because the forms, admin panel and database need the server.

### Using your own PostgreSQL or MongoDB

Open `.env` and change `DB_TYPE`:
- `DB_TYPE=postgres`, and set `DATABASE_URL` (user, password, database name).
- `DB_TYPE=mongodb`, and set `MONGODB_URI` (local MongoDB or MongoDB Atlas).

Save, then restart (Ctrl+C, then `npm run dev`). Tables or collections are created automatically. With Docker, `docker compose up -d` starts both PostgreSQL and MongoDB.

### If it doesn't start

| Message | Fix |
|---|---|
| `node is not recognized` / `command not found` | Install Node.js LTS from nodejs.org, then close and reopen VS Code |
| `Port 3000 is already in use` | Another copy is running: close it, or set `PORT=3001` in `.env` |
| `Could not start the database (builtin)` | Stop the site, delete the `data` folder, start again. (This deletes saved enquiries and edits.) |
| `Could not start the database (postgres/mongodb)` | That database server isn't running or the address in `.env` is wrong. Set `DB_TYPE=builtin` to use the built-in one |

## 3. Admin panel

**Password.** `/admin` asks for the password **every time**: when you open it, when you refresh it, and in every new tab. Nothing is remembered in the browser, so nobody else using the same computer can get in without the password. **Log out** (or closing or refreshing the tab) ends the login. You can change the password in two places, and whichever you changed last is the one that works:
1. **In the code:** edit `ADMIN_PASSWORD` in `admin-config.js` and save. `npm run dev` restarts by itself; with `npm start`, restart it. The new password works straight away and everyone is logged out. This is also how you get back in if you forget a password set in the panel.
2. **In the admin panel:** Settings → Change admin password. From then on the panel password is used, until you edit `admin-config.js` again.

The starting password is `Kathiyawadi@2026`. The terminal always shows which password is active. 5 wrong tries lock the login for 15 minutes. A login also ends after 12 hours (`SESSION_HOURS` in `admin-config.js`).

**Adding a project or product with photos.**
- **Projects → + Add.** The form starts with **Project photo** (Upload photo) and **More photos** (+ Add photos, several at once). Fill in the rest, click **Add**, then **Publish changes**. The photo shows on the project card and the extra photos on the project page.
- **Products → + Add.** Same form with a **Product photo** and **More photos**, plus price, short and full description, and a Published tick. Products appear on `/products`. Each product gets its own page, and a "Products" menu link appears once one is published.
- To change a photo later, click ✎ on the item, then **Upload photo** (or ✕ on a gallery photo), **Done**, **Publish changes**.

**Changing any text, button or link on any page.**
- In the admin panel, go to **Pages & Buttons** and click **Edit page** next to the page. It opens in a new tab with an edit bar at the bottom.
- Click any heading, text or button and change the words. For a button, also change the **link**. You can also tick **Hide this on the website**.
- Click **Apply**, then **Save changes** in the bottom bar. It's live straight away.
- Header and footer changes show on every page.
- Editing ends when you close or refresh that tab. Visitors never see any edit buttons.
- **Pages & Buttons** lists every change with **Undo** buttons.

**Adding your own sections (Content blocks).** Admin → **Content blocks** → **+ Add**. Each block can have:
- a large heading, a small label, a subheading, text (leave an empty line between paragraphs), an image, and a button with its own link;
- a page to show on (or All pages), and a place on the page: after the first section, before the last section, or at the very end;
- a colour style (Light, Dark, Orange, Outlined) and a layout (image right, image left, or centred).

Click **Add**, then **Publish changes**. Untick **Published** to hide a block without deleting it. Only the admin can add or edit blocks.

**Project photos and reels.** Upload project photos at **1080 × 1350 (4:5)**: they show in that frame on the card and the project page, like the home page. Other sizes are cropped to fit. Add a **Project reel** (vertical 9:16 MP4) and the project page plays it in a 9:16 player, using the photo as its cover.

**Hiding a page.** Admin → **Pages & Buttons** → **Hide page** on that row. Visitors then see "page not found", and every link to it disappears from the menu, footer and buttons. Its sub-pages are hidden too (hiding Journal also hides its articles). Click **Show page** to bring it back. The Pricing page starts hidden. The Home page can't be hidden.

**Photos & Reels** (left menu): replace any existing photo, reel, service icon, logo or the loader mark. It goes live when the upload finishes. **Restore original** puts the old one back.

Also in the panel: dashboard, enquiries (status, notes, email / WhatsApp / call, CSV export), bookings, subscribers, editors for Services, Journal, FAQs, Reviews and the announcement bar, and an activity log.

## 4. Commands

| Command | What it does |
|---|---|
| `npm run dev` | Run with auto-restart when you edit server files |
| `npm start` | Run normally (use this on a server) |
| `npm test` | Full test of the site, forms, admin and uploads (uses a separate `_test` database, so your data is safe) |
| `npm run check` | Syntax check of every JavaScript file |

## 5. Files

| Where | What |
|---|---|
| `views/index.html` | The HTML page shell (header, footer). Every page uses it |
| `public/styles.css` | All website styles |
| `public/app.js` | Page content and forms |
| `public/creative.js`, `motion.js`, `page-art.js`, `brand.js` | Animations, reels, artwork |
| `public/media/`, `public/assets/` | Original photos, reels, icons, logo |
| `admin/` | Admin panel pages (`login.html`, `admin.html`, `admin.css`, `admin.js`) |
| `admin-config.js` | Admin password (`ADMIN_PASSWORD`) and login settings |
| `server.js` | Starts the server |
| `src/routes/` | Website pages, form saving, admin API |
| `src/db/postgres.js`, `src/db/mongo.js` | Database code (same features for both) |
| `src/content-defaults.js` | Original site content (used until you edit it in admin) |
| `.env` | Your settings (database, port). Don't share it |
| `data/` | Built-in database files (created on first start). Keep it to keep your data |

## 6. Database contents

| PostgreSQL table / MongoDB collection | Holds |
|---|---|
| `submissions` | Every form: contact, project, booking, career, newsletter |
| `bookings` | Reserved call slots (one booking per slot) |
| `content` | Your edits from the admin panel |
| `media_files`, `media_chunks` | Photos and videos uploaded in the admin panel |
| `admin_meta` | Encrypted admin password, login key, wrong-password counters |
| `admin_log` | Activity log |
| `counters` (MongoDB only) | Running numbers for enquiry IDs |

## 7. Putting it online

Any Node.js host works, for example Render, Railway, a VPS or Hostinger Node hosting:

1. Upload the folder (without `node_modules`), or push it to GitHub and connect it to the host.
2. Build command: `npm install`. Start command: `npm start`.
3. Set the same values as your `.env` in the host's environment settings, plus `NODE_ENV=production`, `TRUST_PROXY=true` and `SITE_URL=https://your-domain`.
4. Use a hosted database: Neon or Supabase (PostgreSQL), or MongoDB Atlas.
