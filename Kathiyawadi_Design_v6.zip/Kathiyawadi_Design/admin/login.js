// Password screen. The login is kept only in this page's memory (window.KD_TOKEN),
// so a refresh, a new tab or opening /admin again always asks for the password.
const f=document.getElementById('login'),msg=document.getElementById('msg'),pw=document.getElementById('pw'),btn=document.getElementById('go');
document.getElementById('show').onclick=e=>{pw.type=pw.type==='password'?'text':'password';e.target.textContent=pw.type==='password'?'Show':'Hide';pw.focus()};
f.onsubmit=async e=>{e.preventDefault();msg.textContent='';btn.disabled=true;btn.textContent='Checking…';
 try{const r=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pw.value})});const j=await r.json().catch(()=>({error:'Something went wrong. Try again.'}));
  if(r.ok&&j.token){window.KD_TOKEN=j.token;pw.value='';document.getElementById('login-screen').hidden=true;document.getElementById('admin-app').hidden=false;window.startAdmin();return}
  msg.textContent=j.error||'Wrong password.';pw.select()}
 catch{msg.textContent='Could not reach the server. Check your connection.'}
 btn.disabled=false;btn.textContent='Log in'};
