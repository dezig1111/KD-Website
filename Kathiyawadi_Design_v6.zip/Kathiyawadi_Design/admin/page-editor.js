/* "Edit this page" mode. Opened from Admin → Pages & Buttons → Edit page with a one-time ticket.
   Click a text or button,
   change it, then Save. Changes are stored as content "pageEdits". */
(function () {
  var EDIT = window.__KD_EDIT__;
  if (!EDIT || !EDIT.token) return;
  var authH = {Authorization: 'Bearer ' + EDIT.token};
  // Remove the one-time ticket from the address bar (a refresh ends editing).
  try { history.replaceState(null, '', location.pathname); } catch (e) {}
  var PE = window.KDPageEdits;
  if (!PE) return;
  var TEXT_TAGS = /^(H1|H2|H3|H4|H5|H6|P|A|BUTTON|LI|SPAN|SMALL|STRONG|EM|B|LABEL|FIGCAPTION|SUMMARY|DT|DD|BLOCKQUOTE|TD|TH|DIV)$/;
  var INLINE_OK = /^(BR|EM|STRONG|B|I|SPAN|SMALL)$/;
  var pending = {};               // key "scope|sel" → edit
  var current = null;             // element being edited
  var original = new Map();       // element → {html, href, display} before editing (for Discard)

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]; }); }
  function scopeOf(el) { return el.closest('body > header, body > footer') ? '*' : PE.path; }
  function selectorFor(el) {
    var parts = [];
    while (el && el !== document.body && el !== document.documentElement) {
      if (el.id && /^[A-Za-z][\w-]*$/.test(el.id) && el.id !== 'kd-editbar') { parts.unshift('#' + el.id); return parts.join('>'); }
      var i = 1, s = el;
      while ((s = s.previousElementSibling)) if (s.tagName === el.tagName) i++;
      parts.unshift(el.tagName.toLowerCase() + ':nth-of-type(' + i + ')');
      el = el.parentElement;
    }
    return 'body>' + parts.join('>');
  }
  // The element to edit: a link/button, or the nearest block whose content is plain text.
  function editableFrom(t) {
    if (!t || t.closest('#kd-editbar, #kd-editpanel, .kd-admin-tools')) return null;
    var link = t.closest('a, button');
    if (link && !link.closest('#kd-editbar')) return link;
    var el = t;
    while (el && el !== document.body) {
      if (TEXT_TAGS.test(el.tagName) && el.textContent.trim() && Array.prototype.every.call(el.children, function (c) { return INLINE_OK.test(c.tagName); })) {
        // Styled words inside a heading or paragraph (bold, italic…) select the whole heading/paragraph.
        while (INLINE_OK.test(el.tagName) && el.parentElement && TEXT_TAGS.test(el.parentElement.tagName) && !/^(A|BUTTON)$/.test(el.parentElement.tagName) && Array.prototype.every.call(el.parentElement.children, function (c) { return INLINE_OK.test(c.tagName); })) el = el.parentElement;
        return el;
      }
      el = el.parentElement;
    }
    return null;
  }
  function textOf(el) {  // visible text with line breaks
    var t = document.createElement('div');
    t.innerHTML = el.innerHTML.replace(/<br\s*\/?>/gi, '\n');
    return t.textContent.replace(/[ \t]+\n/g, '\n').trim();
  }

  // ── UI ─────────────────────────────────────────────
  var bar = document.createElement('div');
  bar.id = 'kd-editbar';
  bar.innerHTML = '<b>✎ Editing this page</b><span id="kd-edit-hint">Click any text or button to change it. Refreshing ends editing.</span><span id="kd-edit-count"></span><button type="button" id="kd-edit-save" disabled>Save changes</button><button type="button" id="kd-edit-discard">Discard</button><button type="button" id="kd-edit-exit">Exit</button>';
  var panel = document.createElement('div');
  panel.id = 'kd-editpanel';
  panel.hidden = true;
  document.body.append(bar, panel);
  document.documentElement.classList.add('kd-editing');

  function count() { var n = Object.keys(pending).length; document.getElementById('kd-edit-count').textContent = n ? n + ' unsaved change' + (n > 1 ? 's' : '') : ''; document.getElementById('kd-edit-save').disabled = !n; }
  function hover(e) { var el = editableFrom(e.target); document.querySelectorAll('.kd-edit-hover').forEach(function (x) { if (x !== el) x.classList.remove('kd-edit-hover'); }); if (el) el.classList.add('kd-edit-hover'); }

  function open(el) {
    current = el;
    var link = el.closest('a');
    if (!original.has(el)) original.set(el, {html: el.innerHTML, href: link && link.getAttribute('href'), display: el.style.display});
    var where = scopeOf(el) === '*' ? 'Header / footer: changes show on every page.' : 'This page only.';
    panel.innerHTML = '<header><b>' + (link ? 'Edit button / link' : 'Edit text') + '</b><button type="button" data-close aria-label="Close">✕</button></header>'
      + '<label>Text<textarea id="kd-edit-text" rows="4">' + esc(textOf(el)) + '</textarea><small>Press Enter for a new line.</small></label>'
      + (link ? '<label>Link (where the button goes)<input id="kd-edit-href" value="' + esc(link.getAttribute('href') || '') + '" placeholder="/contact or https://…"><small>A page on this site starts with / (for example /contact). Other websites start with https://. Also mailto: and tel:.</small></label>' : '')
      + '<label class="kd-check"><input type="checkbox" id="kd-edit-hide"> Hide this on the website</label>'
      + '<p class="kd-where">' + where + '</p><div class="kd-row"><button type="button" id="kd-edit-apply">Apply</button><button type="button" data-close>Cancel</button></div>';
    panel.hidden = false;
    var ta = document.getElementById('kd-edit-text');
    ta.focus();
    panel.querySelectorAll('[data-close]').forEach(function (b) { b.onclick = close; });
    document.getElementById('kd-edit-apply').onclick = function () {
      var text = ta.value.trim();
      var hide = document.getElementById('kd-edit-hide').checked;
      var hrefInput = document.getElementById('kd-edit-href');
      if (!text && !hide) return alert('Text can’t be empty. Tick “Hide this” to remove it instead.');
      var edit = {sel: selectorFor(el)};
      if (hide) edit.hide = true;
      else edit.html = esc(text).replace(/\n/g, '<br>');
      if (hrefInput && !hide) {
        var href = hrefInput.value.trim();
        if (href && !PE.safeHref(href)) return alert('The link must start with /, https://, http://, mailto: or tel:');
        if (href) edit.href = href;
      }
      // Keep a button's arrow icon and other small parts when only the words changed.
      if (edit.html && textOf(el) === text) delete edit.html;
      pending[scopeOf(el) + '|' + edit.sel] = Object.assign(pending[scopeOf(el) + '|' + edit.sel] || {}, edit);
      PE.applyOne(edit);
      el.classList.add('kd-edit-changed');
      close(); count();
    };
  }
  function close() { panel.hidden = true; current = null; }

  document.addEventListener('mouseover', hover, true);
  document.addEventListener('click', function (e) {
    if (e.target.closest('#kd-editbar, #kd-editpanel')) return;
    var el = editableFrom(e.target);
    e.preventDefault(); e.stopPropagation();
    if (el) open(el);
  }, true);
  document.addEventListener('submit', function (e) { e.preventDefault(); }, true);

  document.getElementById('kd-edit-exit').onclick = function () {
    if (Object.keys(pending).length && !confirm('Leave without saving your changes?')) return;
    location.href = location.pathname;
  };
  document.getElementById('kd-edit-discard').onclick = function () {
    if (!Object.keys(pending).length || confirm('Discard all unsaved changes on this page?')) location.reload();
  };
  document.getElementById('kd-edit-save').onclick = async function () {
    var btn = this;
    btn.disabled = true; btn.textContent = 'Saving…';
    try {
      var r = await fetch('/api/admin', {cache: 'no-store', headers: authH});
      if (r.status === 401) throw new Error('Your login has ended. Open the page again from Admin → Pages & Buttons.');
      var data = await r.json();
      var edits = JSON.parse(JSON.stringify((data.content && data.content.pageEdits) || {}));
      Object.keys(pending).forEach(function (k) {
        var scope = k.split('|')[0], e = pending[k];
        var list = edits[scope] = (edits[scope] || []).filter(function (x) { return x.sel !== e.sel; });
        var old = ((PE.all[scope] || []).find(function (x) { return x.sel === e.sel; })) || {};
        list.push(Object.assign({}, e.hide ? {} : old, e, e.hide ? {} : {hide: undefined}));
      });
      Object.keys(edits).forEach(function (s) { edits[s] = edits[s].map(function (x) { var y = {}; Object.keys(x).forEach(function (k) { if (x[k] !== undefined) y[k] = x[k]; }); return y; }); });
      var s = await fetch('/api/admin', {method: 'POST', headers: Object.assign({'Content-Type': 'application/json'}, authH), body: JSON.stringify({action: 'saveContent', key: 'pageEdits', value: edits})});
      var j = await s.json().catch(function () { return {}; });
      if (!s.ok) throw new Error(j.error || 'Could not save.');
      pending = {}; PE.all = edits; count();
      btn.textContent = 'Saved ✓';
      setTimeout(function () { btn.textContent = 'Save changes'; }, 1800);
    } catch (err) { alert(err.message); btn.textContent = 'Save changes'; count(); }
  };
  addEventListener('beforeunload', function (e) { if (Object.keys(pending).length) { e.preventDefault(); e.returnValue = ''; } });
})();
