@echo off
title Kathiyawadi Design
cd /d "%~dp0"
where node >nul 2>nul || (echo. & echo  Node.js is not installed. Download the LTS version from https://nodejs.org, install it, then double-click this file again. & echo. & pause & exit /b 1)
if not exist .env copy .env.example .env >nul
if not exist node_modules (echo  Installing for the first time, please wait... & call npm install || (pause & exit /b 1))
start "" http://localhost:3000
call npm run dev
pause
