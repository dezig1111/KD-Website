#!/bin/bash
# Double-click to start the website on Linux.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo; echo "  Node.js is not installed. Download the LTS version from https://nodejs.org, install it, then double-click this file again."; echo
  read -p "Press Enter to close"; exit 1
fi
[ -f .env ] || cp .env.example .env
[ -d node_modules ] || { echo "  Installing for the first time, please wait..."; npm install || { read -p "Press Enter to close"; exit 1; }; }
(sleep 6; (xdg-open http://localhost:3000 || true)) &
npm run dev
