// ─────────────────────────────────────────────────────────────
// ADMIN PANEL PASSWORD
//
// Anyone who opens /admin must type the password first.
//
// You can change the password in TWO places. Whichever you changed last is used:
//
//   1. Here in the code: edit ADMIN_PASSWORD below and save.
//      `npm run dev` restarts by itself; with `npm start`, restart the server.
//      The new password works straight away and everyone is logged out.
//      (This is also the way back in if you forget a password set in the admin panel.)
//
//   2. In the admin panel: Settings → Change admin password.
//      From then on the panel password is used, until you edit ADMIN_PASSWORD here again.
// ─────────────────────────────────────────────────────────────
export const ADMIN_PASSWORD = 'Kathiyawadi@2026';

// The password is asked every time /admin is opened or refreshed.
// A login also ends after this many hours, even if the page stays open.
export const SESSION_HOURS = 12;

// Wrong-password protection: after this many wrong tries the login is
// locked for LOCK_MINUTES (per internet connection).
export const MAX_ATTEMPTS = 5;
export const LOCK_MINUTES = 15;
