// End-to-end test of the website, forms, admin login, uploads and content editing.
// Uses the database from .env, but in a separate test database / test collection set
// that is wiped first: built-in/PostgreSQL → <db name>_test, MongoDB → <MONGODB_DB>_test
//   npm test
import 'dotenv/config';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createApp} from '../server.js';

const env = {...process.env};
const type = (env.DB_TYPE || 'postgres').toLowerCase();
if (type === 'builtin' || type === 'built-in' || type === 'local') {
  env.BUILTIN_DB_NAME = (env.BUILTIN_DB_NAME || 'kathiyawadi') + '_test';
} else if (type.startsWith('postgres')) {
  const url = new URL(env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/kathiyawadi');
  const testDb = url.pathname.slice(1) + '_test';
  const pg = (await import('pg')).default;
  const admin = new pg.Client({connectionString: url.toString()});
  await admin.connect();
  await admin.query(`DROP DATABASE IF EXISTS "${testDb}"`);
  await admin.query(`CREATE DATABASE "${testDb}"`);
  await admin.end();
  url.pathname = '/' + testDb;
  env.DATABASE_URL = url.toString();
} else {
  env.MONGODB_DB = (env.MONGODB_DB || 'kathiyawadi') + '_test';
  const {MongoClient} = await import('mongodb');
  const c = new MongoClient(env.MONGODB_URI || 'mongodb://localhost:27017');
  await c.connect(); await c.db(env.MONGODB_DB).dropDatabase(); await c.close();
}

let {app, db} = await createApp(env);
if (db.wipe) { await db.wipe(); await db.close(); ({app, db} = await createApp(env)); }
let server = await new Promise(r => { const s = app.listen(0, () => r(s)); });
let B = `http://localhost:${server.address().port}`;
let token = '';     // the admin login lives only in the open page, sent as a header
let setCookie = false;
let passed = 0;
const ok = (cond, msg) => { assert.ok(cond, msg); passed++; };
async function call(path, {method = 'GET', body, headers = {}, raw} = {}) {
  const h = {origin: B, ...(token ? {authorization: 'Bearer ' + token} : {}), ...headers};
  if (body !== undefined && !raw) h['content-type'] = 'application/json';
  const r = await fetch(B + path, {method, headers: h, body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined), redirect: 'manual'});
  if (r.headers.get('set-cookie')) setCookie = true;
  const text = await r.text();
  let json; try { json = JSON.parse(text); } catch { /* not json */ }
  if (json && typeof json.token === 'string') token = json.token;
  return {status: r.status, text, json, headers: r.headers};
}

try {
  // Public pages
  for (const p of ['/', '/about', '/services', '/work', '/work/savor', '/blog/logo-grid', '/contact', '/book-a-call', '/faq']) ok((await call(p)).status === 200, p + ' should load');
  ok((await call('/no-such-page')).status === 404, 'unknown page is 404');
  ok((await call('/styles.css')).status === 200 && (await call('/media-swap.js')).status === 200, 'static files');
  const home = await call('/');
  ok(!(await call('/')).text.includes('kd-admin-fab'), 'website shows no admin buttons');
  ok((await call('/start-project?x=1')).headers.get('location') === '/contact?x=1', 'old link redirects');

  // Forms
  const valid = {kind: 'contact', name: 'QA Client', email: 'QA@Example.com', phone: '+91 98765 43210', message: 'A sample website project brief.', consent: 'yes'};
  ok((await call('/api/submit', {method: 'POST', body: valid})).status === 200, 'contact form saves');
  ok((await call('/api/submit', {method: 'POST', body: {...valid, consent: false}})).status === 400, 'consent required');
  ok((await call('/api/submit', {method: 'POST', body: {...valid, email: 'bad'}})).status === 400, 'email checked');
  ok((await call('/api/submit', {method: 'POST', body: valid, headers: {origin: 'https://evil.example'}})).status === 403, 'other websites blocked');
  ok((await call('/api/submit', {method: 'POST', raw: '{', headers: {'content-type': 'application/json'}})).status === 400, 'bad JSON rejected');
  ok((await call('/api/submit', {method: 'POST', body: {...valid, message: 'x'.repeat(21000)}})).status === 413, 'too long rejected');
  ok((await call('/api/submit', {method: 'POST', body: {...valid, $where: 'x'}})).status === 400, 'odd field names rejected');
  ok((await call('/api/submit', {method: 'POST', body: {kind: 'newsletter', email: 'fan@example.com'}})).status === 200, 'newsletter saves');
  const slot = new Date(Date.now() + 86400000); slot.setUTCHours(4, 30, 0, 0); if (slot.getUTCDay() === 0) slot.setUTCDate(slot.getUTCDate() + 1);
  const booking = {kind: 'booking', name: 'Booker', email: 'book@example.com', consent: 'yes', slot: slot.toISOString()};
  ok((await call('/api/submit', {method: 'POST', body: booking})).status === 200, 'booking saves');
  ok((await call('/api/submit', {method: 'POST', body: {...booking, email: 'other@example.com'}})).status === 409, 'double booking blocked');

  // Admin: locked until password
  ok((await call('/admin')).text.includes('Admin login'), '/admin shows login page');
  ok((await call('/api/admin')).status === 401, 'admin API needs login');
  ok((await call('/api/admin/login', {method: 'POST', body: {password: 'wrong'}})).status === 401, 'wrong password refused');
  const first = await call('/api/admin/login', {method: 'POST', body: {password: 'Kathiyawadi@2026'}});
  ok(first.status === 200 && token, 'password from admin-config.js works');
  ok(!setCookie, 'nothing is remembered in the browser (no cookie)');
  ok((await call('/admin')).text.includes('Admin login'), '/admin asks for the password again on every visit / refresh');
  { const keep = token; token = ''; ok((await call('/api/admin')).status === 401, 'a new tab without the login is locked'); token = keep; }
  ok((await call('/api/admin')).json.passwordSource === 'code', 'panel says the code password is in use');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'changePassword', current: 'Kathiyawadi@2026', password: 'short'}})).status === 400, 'short password refused');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'changePassword', current: 'wrong', password: 'MyNewPass#99'}})).status === 400, 'current password checked');
  const oldToken = token;
  ok((await call('/api/admin', {method: 'POST', body: {action: 'changePassword', current: 'Kathiyawadi@2026', password: 'MyNewPass#99'}})).status === 200 && token !== oldToken, 'password changed in admin panel (this page stays logged in)');
  { const keep = token; token = oldToken; ok((await call('/api/admin')).status === 401, 'other open admin pages are logged out'); token = keep; }
  ok((await call('/api/admin')).json.passwordSource === 'admin', 'panel says the admin-panel password is in use');
  const data = (await call('/api/admin')).json;
  ok(data.submissions.length === 3 && data.bookings.length === 1 && data.mediaSlots.length > 20, 'admin sees enquiries and bookings');
  ok(data.submissions.find(s => s.kind === 'contact').email === 'qa@example.com', 'email stored lower-case');
  ok((await call('/admin-assets/admin.js')).status === 200, 'admin panel script loads');
  ok(!(await call('/')).text.includes('kd-admin-fab'), 'website shows no admin buttons');

  // Enquiries
  const contact = data.submissions.find(s => s.kind === 'contact');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'updateSubmission', id: contact.id, status: 'won', note: 'Quote sent'}})).status === 200, 'status + note saved');
  const after = (await call('/api/admin')).json.submissions.find(s => s.id === contact.id);
  ok(after.status === 'won' && after.note === 'Quote sent' && after.updatedAt, 'status + note stored');
  const bookingRow = data.submissions.find(s => s.kind === 'booking');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'deleteSubmission', id: bookingRow.id}})).status === 200, 'booking enquiry deleted');
  ok((await call('/api/submit', {method: 'POST', body: {...booking, email: 'other@example.com'}})).status === 200, 'freed slot can be booked again');

  // Content
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'settings', value: {announcement: 'Now booking', announcementLink: '/contact'}}})).status === 200, 'settings saved');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'projects', value: [{slug: 'new-brand', title: 'New Brand', category: 'Graphic', industry: 'Retail', color: '#eee', wordmark: 'NB', tagline: 'Hi', image: ''}]}})).status === 200, 'projects saved');
  ok((await call('/work/new-brand')).status === 200 && (await call('/')).text.includes('Now booking'), 'website shows saved content');

  // Upload a 2 MB file in pieces, then use it as a replacement photo
  const bytes = crypto.randomBytes(2_100_000);
  const start = await call('/api/admin', {method: 'POST', body: {action: 'uploadStart', name: 'photo.png', type: 'image/png', size: bytes.length}});
  ok(start.status === 200 && start.json.chunks === 3, 'upload started');
  for (let i = 0; i < start.json.chunks; i++) {
    const r = await call(`/api/admin/upload?id=${start.json.id}&idx=${i}`, {method: 'POST', raw: bytes.subarray(i * start.json.chunkBytes, (i + 1) * start.json.chunkBytes), headers: {'content-type': 'application/octet-stream'}});
    ok(r.status === 200, 'piece ' + i + ' uploaded');
  }
  const fin = await call('/api/admin', {method: 'POST', body: {action: 'uploadFinish', id: start.json.id}});
  ok(fin.status === 200 && fin.json.url.startsWith('/uploads/'), 'upload finished');
  const whole = Buffer.from(await (await fetch(B + fin.json.url)).arrayBuffer());
  ok(whole.equals(bytes), 'downloaded file is identical');
  const part = await fetch(B + fin.json.url, {headers: {range: 'bytes=786000-786999'}});
  ok(part.status === 206 && Buffer.from(await part.arrayBuffer()).equals(bytes.subarray(786000, 787000)), 'video seeking (Range) works across pieces');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'media', value: {'/media/cafe-campaign.webp': fin.json.url}}})).status === 200, 'photo replaced');
  ok((await call('/')).text.includes(fin.json.url), 'website uses replaced photo');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'deleteUpload', url: fin.json.url}})).status === 400, 'file in use cannot be deleted');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'media', value: {'/not/a/slot.jpg': fin.json.url}}})).status === 400, 'unknown photo slot refused');

  // Pricing page switch
  ok((await call('/pricing')).status === 404, 'pricing page hidden by default');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'settings', value: {announcement: '', announcementLink: '', showPricing: true}}})).status === 200, 'pricing switched on');
  ok((await call('/pricing')).status === 200, 'pricing page shown when switched on');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'settings', value: {announcement: '', announcementLink: '', hiddenPages: ['/blog', '/careers']}}})).status === 200, 'pages hidden from admin');
  ok((await call('/blog')).status === 404 && (await call('/blog/logo-grid')).status === 404 && (await call('/careers')).status === 404, 'hidden pages and their sub-pages show not found');
  ok((await call('/')).status === 200 && (await call('/pricing')).status === 200, 'other pages still visible');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'settings', value: {announcement: '', announcementLink: '', hiddenPages: []}}})).status === 200 && (await call('/blog')).status === 200, 'hidden page shown again');

  // Page text / button edits
  const ticket = (await call('/api/admin', {method: 'POST', body: {action: 'editTicket'}})).json.ticket;
  { const keep = token; token = '';
    const editPage = await call('/?edit=' + ticket);
    ok(editPage.text.includes('page-editor.js') && editPage.text.includes('__KD_EDIT__'), 'Edit page opens in edit mode with a one-time ticket');
    ok(!(await call('/?edit=' + ticket)).text.includes('page-editor.js'), 'refreshing the edit page ends editing (ticket used up)');
    ok(!(await call('/?edit=' + 'a'.repeat(24))).text.includes('page-editor.js'), 'made-up ticket refused');
    token = keep; }
  ok((await call('/')).text.includes('/page-edits.js'), 'page changes script on the website');
  const edits = {'/': [{sel: '#app>section:nth-of-type(1) h1', html: 'New <em>headline</em>'}, {sel: '#app a.button', href: '/products'}], '*': [{sel: 'body>footer:nth-of-type(1) a', hide: true}]};
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'pageEdits', value: edits}})).status === 200, 'page edits saved');
  ok((await call('/')).text.includes('New \\u003cem>headline'), 'page edits sent to the website');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'pageEdits', value: {'/': [{sel: 'a', href: 'javascript:alert(1)'}]}}})).status === 400, 'unsafe link refused');
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'pageEdits', value: {'/': [{sel: 'a', onclick: 'x'}]}}})).status === 400, 'unknown edit fields refused');

  // Products (with photo and gallery)
  const product = {name: 'Brand Starter Kit', image: fin.json.url, gallery: [fin.json.url], slug: 'brand-starter-kit', category: 'Template', price: '₹4,999', summary: 'Logo + colours', description: 'Everything to start.', published: true};
  ok((await call('/api/admin', {method: 'POST', body: {action: 'saveContent', key: 'products', value: [product, {...product, slug: 'hidden-one', name: 'Hidden', published: false}]}})).status === 200, 'products saved');
  ok((await call('/products')).status === 200 && (await call('/products/brand-starter-kit')).status === 200, 'product pages load');
  ok((await call('/products/hidden-one')).status === 404, 'hidden product not shown');
  ok((await call('/')).text.includes('Brand Starter Kit'), 'products sent to the website');

  // Logout + new password
  ok((await call('/api/admin/logout', {method: 'POST'})).status === 200, 'logged out'); token = '';
  ok(!(await call('/')).text.includes('page-editor.js'), 'page editor not loaded for visitors');
  ok((await call('/api/admin')).status === 401, 'locked again after logout');
  ok((await call('/api/admin/login', {method: 'POST', body: {password: 'Kathiyawadi@2026'}})).status === 401, 'old code password stops working after a panel change');
  ok((await call('/api/admin/login', {method: 'POST', body: {password: 'MyNewPass#99'}})).status === 200, 'panel password works');

  // Restart with the same admin-config.js password: the panel password stays
  const restart = async adminPassword => {
    server.close(); await db.close();
    ({app, db} = await createApp(env, {adminPassword}));
    server = await new Promise(r => { const s = app.listen(0, () => r(s)); });
    B = `http://localhost:${server.address().port}`;
  };
  await restart('Kathiyawadi@2026');
  ok((await call('/api/admin/login', {method: 'POST', body: {password: 'MyNewPass#99'}})).status === 200, 'panel password kept after restart');
  // Restart after editing ADMIN_PASSWORD in admin-config.js: the code password wins
  await restart('CodePass#2027');
  ok((await call('/api/admin')).status === 401, 'editing the code password logs everyone out');
  ok((await call('/api/admin/login', {method: 'POST', body: {password: 'MyNewPass#99'}})).status === 401, 'old panel password replaced by code password');
  ok((await call('/api/admin/login', {method: 'POST', body: {password: 'CodePass#2027'}})).status === 200, 'new code password works');
  ok((await call('/api/admin')).json.passwordSource === 'code', 'panel says the code password is in use again');

  console.log(`\n  ✔ ${passed} checks passed on ${db.name}\n`);
} catch (e) {
  console.error(`\n  ✘ Failed after ${passed} passing checks on ${db.name}:`, e.message, '\n');
  process.exitCode = 1;
} finally {
  server.close();
  await db.close();
}
