// Checks every JavaScript file for syntax errors (npm run check).
import {execFileSync} from 'node:child_process';
import {readdirSync, statSync} from 'node:fs';
import path from 'node:path';
const files = [];
const walk = dir => { for (const f of readdirSync(dir)) { const p = path.join(dir, f); if (statSync(p).isDirectory()) { if (!['node_modules', 'media', 'assets'].includes(f)) walk(p); } else if (/\.(m?js)$/.test(f)) files.push(p); } };
['server.js', 'admin-config.js'].forEach(f => files.push(f));
['src', 'public', 'admin', 'tests'].forEach(walk);
for (const f of files) execFileSync(process.execPath, ['--check', f], {stdio: 'inherit'});
console.log(`Syntax OK in ${files.length} files.`);
