// Kathiyawadi Design — website + admin panel.
// Start with:  npm start   (or npm run dev for auto-restart while editing)
const [major] = process.versions.node.split('.').map(Number);
if (major < 20) {
  console.error(`\n  This website needs Node.js 20 or newer. You have ${process.versions.node}.\n  Download the LTS version from https://nodejs.org and try again.\n`);
  process.exit(1);
}
import 'dotenv/config';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import express from 'express';
import {createDatabase} from './src/db/index.js';
import {createAuth} from './src/auth.js';
import {createMedia} from './src/media.js';
import {siteRoutes} from './src/routes/site.js';
import {submitRoutes} from './src/routes/submit.js';
import {adminRoutes} from './src/routes/admin.js';
import {ADMIN_PASSWORD} from './admin-config.js';

const root = path.dirname(fileURLToPath(import.meta.url));

export async function createApp(env = process.env, options = {}) {
  const db = createDatabase(env);
  await db.init();
  const auth = createAuth(db, {codePassword: options.adminPassword});
  const codeApplied = await auth.syncCodePassword();
  const media = createMedia(db);

  const app = express();
  app.disable('x-powered-by');
  // Behind a hosting proxy (Render, Railway, Nginx…) set TRUST_PROXY=true in .env
  // so HTTPS cookies and the wrong-password lockout see the real visitor address.
  app.set('trust proxy', env.TRUST_PROXY === 'true' ? true : 'loopback');
  app.use((req, res, next) => { res.set({'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin'}); next(); });

  // Static files: public/styles.css, public/app.js, public/media/… (no index.html here on purpose)
  app.use(express.static(path.join(root, 'public'), {index: false, maxAge: env.NODE_ENV === 'production' ? '1h' : 0}));

  submitRoutes(app, {db});
  adminRoutes(app, {db, auth, media, root});
  siteRoutes(app, {db, auth, root});

  app.use((req, res) => res.status(404).send('Not found'));
  app.use((err, req, res, _next) => {
    if (err.type === 'entity.too.large') return res.status(413).json({error: 'Message too long'});
    if (err.type === 'entity.parse.failed') return res.status(400).json({error: 'Invalid JSON'});
    console.error(err);
    res.status(500).json({error: 'Something went wrong. Please try again.'});
  });
  return {app, db, auth, codeApplied};
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  try {
    const {app, db, auth, codeApplied} = await createApp();
    const fromCode = (await auth.passwordSource()) === 'code';
    const server = app.listen(port, () => {
      console.log(`\n  Kathiyawadi Design is running → http://localhost:${port}`);
      console.log(`  Admin panel → http://localhost:${port}/admin` + (fromCode ? `   (password: ${ADMIN_PASSWORD} from admin-config.js)` : '   (password: the one set in Admin > Settings)'));
      console.log(`  Database: ${db.name}`);
      if (codeApplied) console.log('  The password in admin-config.js is now active.');
      console.log('  Press Ctrl+C to stop.\n');
    });
    server.on('error', e => {
      console.error(e.code === 'EADDRINUSE' ? `\n  Port ${port} is already in use. Close the other program or set PORT=3001 in .env\n` : e);
      process.exit(1);
    });
    const stop = async () => { server.close(); await db.close().catch(() => {}); process.exit(0); };
    process.on('SIGINT', stop);
    process.on('SIGTERM', stop);
  } catch (e) {
    const type = (process.env.DB_TYPE || 'builtin').toLowerCase();
    console.error('\n  Could not start the database (' + type + ').');
    if (type.startsWith('postgres')) console.error('  Is PostgreSQL installed and running, and is DATABASE_URL in .env correct?');
    else if (type.startsWith('mongo')) console.error('  Is MongoDB installed and running (or your Atlas address correct), and is MONGODB_URI in .env correct?');
    else console.error('  Try deleting the "data" folder and run again. If it still fails, run "npm install" again.');
    console.error('  Easiest option: set DB_TYPE=builtin in .env — it needs no database installation.');
    console.error('  Details:', e.message, '\n');
    process.exit(1);
  }
}
